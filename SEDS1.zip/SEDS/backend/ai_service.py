"""SEDS AI Service Module.

Provides integration with OpenAI and optional Google Gemini APIs for:
- Deep error explanations
- Root cause analysis
- Code repair suggestions
- Debugging recommendations

Rules:
- API keys loaded securely from environment / .env (never exposed).
- Explicit user consent required before sending code to external APIs.
- AI is optional: falls back gracefully if API key is not configured or unavailable.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional

from dotenv import load_dotenv

# Load local .env if present
load_dotenv()


class AIService:
    """Manages AI interactions with OpenAI and Gemini."""

    @classmethod
    def get_status(cls) -> Dict[str, Any]:
        """Check AI provider availability without exposing keys."""
        openai_key = os.getenv("OPENAI_API_KEY", "").strip()
        gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
        return {
            "openai_configured": bool(openai_key),
            "gemini_configured": bool(gemini_key),
            "active_provider": "openai" if openai_key else ("gemini" if gemini_key else "offline_heuristic"),
        }

    @classmethod
    def explain_and_fix(
        cls,
        error_info: Dict[str, Any],
        source_code: str,
        user_consent: bool = False,
        preferred_provider: str = "auto",
    ) -> Optional[Dict[str, Any]]:
        """Call external AI (OpenAI/Gemini) if consent is given and key is configured.

        Returns None if AI is disabled or consent is not granted, allowing fallback to local engine.
        """
        if not user_consent:
            return None

        status = cls.get_status()
        if not status["openai_configured"] and not status["gemini_configured"]:
            return None

        provider = status["active_provider"] if preferred_provider == "auto" else preferred_provider

        system_prompt = (
            "You are SEDS (Smart Error Detection System), an expert Python debugging assistant. "
            "Analyze the given Python error and source code, then respond strictly with a valid JSON object "
            "containing these exact keys:\n"
            "1. what: Simple summary of what the error is\n"
            "2. where: Exactly where the error starts (line & column)\n"
            "3. why: Why the error happened conceptually\n"
            "4. cause: What specifically in the code caused it\n"
            "5. affected: Which variables/statements/lines are affected\n"
            "6. how_to_fix: Clear step-by-step instructions in simple English for students\n"
            "7. corrected_code: Complete corrected Python code string\n"
            "8. confidence: High, Medium, or Low\n"
            "Never invent variable values or arbitrarily change program logic."
        )

        user_prompt = (
            f"Error Type: {error_info.get('error_type')}\n"
            f"Line: {error_info.get('line')}, Column: {error_info.get('column')}\n"
            f"Message: {error_info.get('message')}\n"
            f"Source Snippet: {error_info.get('source_snippet')}\n\n"
            f"Full Source Code:\n```python\n{source_code}\n```"
        )

        try:
            if provider == "openai" and status["openai_configured"]:
                return cls._call_openai(system_prompt, user_prompt)
            elif provider == "gemini" and status["gemini_configured"]:
                return cls._call_gemini(system_prompt, user_prompt)
        except Exception as exc:
            # AI call failed (network, quota, etc.); return fallback notification
            return {
                "ai_error": f"AI provider request failed: {exc}. Using local rule-based engine.",
                "fallback": True,
            }

        return None

    @classmethod
    def _call_openai(cls, system_prompt: str, user_prompt: str) -> Optional[Dict[str, Any]]:
        import openai

        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip()
        client = openai.OpenAI(api_key=api_key)

        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            response_format={"type": "json_object"},
            temperature=0.2,
        )
        content = response.choices[0].message.content
        if content:
            return json.loads(content)
        return None

    @classmethod
    def _call_gemini(cls, system_prompt: str, user_prompt: str) -> Optional[Dict[str, Any]]:
        from google import genai

        api_key = os.getenv("GEMINI_API_KEY", "").strip()
        model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
        client = genai.Client(api_key=api_key)

        prompt = f"{system_prompt}\n\n{user_prompt}\nRespond strictly with JSON."
        response = client.models.generate_content(
            model=model,
            contents=prompt,
        )
        text = response.text or ""
        # Clean potential markdown fences
        clean_text = text.strip()
        if clean_text.startswith("```json"):
            clean_text = clean_text[7:]
        if clean_text.startswith("```"):
            clean_text = clean_text[3:]
        if clean_text.endswith("```"):
            clean_text = clean_text[:-3]
        return json.loads(clean_text.strip())
