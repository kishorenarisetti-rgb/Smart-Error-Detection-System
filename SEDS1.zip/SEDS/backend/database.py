"""SEDS Database Management.

SQLite storage for:
- Debugging sessions
- Error history & trends
- Applied fixes and diffs
- Project scan reports
- Execution statistics
"""

from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

DB_PATH = Path(os.getenv("DATABASE_PATH", str(Path(__file__).parent.parent / "seds.db")))


class Database:
    """SQLite database manager for SEDS."""

    @classmethod
    def get_connection(cls) -> sqlite3.Connection:
        conn = sqlite3.connect(str(DB_PATH))
        conn.row_factory = sqlite3.Row
        return conn

    @classmethod
    def init_db(cls) -> None:
        """Create necessary database tables if they do not exist."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()

            # Sessions table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    source_code TEXT NOT NULL,
                    error_type TEXT,
                    error_line INTEGER,
                    error_message TEXT,
                    applied_fix TEXT,
                    execution_output TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

            # Error History table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS error_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER,
                    error_type TEXT NOT NULL,
                    error_message TEXT NOT NULL,
                    line INTEGER,
                    column INTEGER,
                    source_snippet TEXT,
                    fixed_successfully BOOLEAN DEFAULT 0,
                    provider_used TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(session_id) REFERENCES sessions(id)
                )
                """
            )

            # Project Scans table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS project_scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    folder_path TEXT NOT NULL,
                    total_files INTEGER NOT NULL,
                    passed_files INTEGER NOT NULL,
                    failed_files INTEGER NOT NULL,
                    report_json TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

            conn.commit()

    @classmethod
    def save_session(
        cls,
        title: str,
        source_code: str,
        error_type: Optional[str] = None,
        error_line: Optional[int] = None,
        error_message: Optional[str] = None,
        applied_fix: Optional[str] = None,
        execution_output: Optional[str] = None,
    ) -> int:
        """Store a debugging session."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO sessions (title, source_code, error_type, error_line, error_message, applied_fix, execution_output)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (title, source_code, error_type, error_line, error_message, applied_fix, execution_output),
            )
            session_id = cursor.lastrowid
            conn.commit()
            return session_id

    @classmethod
    def log_error(
        cls,
        error_type: str,
        error_message: str,
        line: int,
        column: int = 1,
        source_snippet: str = "",
        session_id: Optional[int] = None,
        fixed_successfully: bool = False,
        provider_used: str = "local",
    ) -> int:
        """Log a detected error into history."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO error_history (session_id, error_type, error_message, line, column, source_snippet, fixed_successfully, provider_used)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (session_id, error_type, error_message, line, column, source_snippet, 1 if fixed_successfully else 0, provider_used),
            )
            record_id = cursor.lastrowid
            conn.commit()
            return record_id

    @classmethod
    def save_scan(
        cls,
        folder_path: str,
        total_files: int,
        passed_files: int,
        failed_files: int,
        report_data: Dict[str, Any],
    ) -> int:
        """Store project scan summary and full report JSON."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO project_scans (folder_path, total_files, passed_files, failed_files, report_json)
                VALUES (?, ?, ?, ?, ?)
                """,
                (folder_path, total_files, passed_files, failed_files, json.dumps(report_data)),
            )
            scan_id = cursor.lastrowid
            conn.commit()
            return scan_id

    @classmethod
    def get_recent_sessions(cls, limit: int = 20) -> List[Dict[str, Any]]:
        """Retrieve recent debugging sessions."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM sessions ORDER BY created_at DESC LIMIT ?", (limit,)
            )
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    @classmethod
    def get_scan_history(cls, limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve past project scans."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, folder_path, total_files, passed_files, failed_files, created_at FROM project_scans ORDER BY created_at DESC LIMIT ?",
                (limit,),
            )
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    @classmethod
    def get_analytics(cls) -> Dict[str, Any]:
        """Generate summary statistics for dashboard."""
        with cls.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM sessions")
            total_sessions = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM error_history")
            total_errors = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM error_history WHERE fixed_successfully = 1")
            fixed_errors = cursor.fetchone()[0]

            cursor.execute(
                "SELECT error_type, COUNT(*) as count FROM error_history GROUP BY error_type ORDER BY count DESC LIMIT 5"
            )
            top_errors = [dict(row) for row in cursor.fetchall()]

            return {
                "total_sessions": total_sessions,
                "total_errors_detected": total_errors,
                "fixes_applied": fixed_errors,
                "top_errors": top_errors,
            }
