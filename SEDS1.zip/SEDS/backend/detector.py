"""SEDS Error Detection Engine.

Uses Python AST, Tokenize, and Traceback analysis to detect:
1. SyntaxError
2. NameError
3. TypeError
4. IndexError
5. ZeroDivisionError
6. IndentationError
7. TabError
8. KeyError
9. ValueError
10. AttributeError
11. ImportError
12. ModuleNotFoundError

Also identifies token and structural issues:
- Missing parentheses, brackets, curly braces
- Missing quotation marks
- Missing colons
- Incorrect indentation & mixed tabs
- Undefined variables
- Incorrect operators & function arguments
- Potential logical errors
"""

from __future__ import annotations

import ast
import builtins
import io
import re
import token
import tokenize
from dataclasses import asdict, dataclass
from typing import Any, List, Optional


@dataclass
class DetectedError:
    error_type: str
    message: str
    line: int
    column: int = 1
    end_line: Optional[int] = None
    end_column: Optional[int] = None
    source_snippet: str = ""
    category: str = "syntax"  # 'token', 'syntax', 'ast_static', 'runtime', 'logical'
    severity: str = "error"   # 'error', 'warning', 'info'
    details: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class TokenAnalyzer:
    """Performs token-level inspection for unclosed brackets, quotes, and tabs."""

    BRACKET_PAIRS = {"(": ")", "[": "]", "{": "}"}
    REVERSE_BRACKET_PAIRS = {")": "(", "]": "[", "}": "{"}

    @classmethod
    def analyze(cls, code: str) -> List[DetectedError]:
        errors: List[DetectedError] = []
        lines = code.splitlines()

        # Check for mixed tabs and spaces first
        for idx, line in enumerate(lines, start=1):
            leading = line[: len(line) - len(line.lstrip())]
            if "\t" in leading and " " in leading:
                errors.append(
                    DetectedError(
                        error_type="TabError",
                        message="Inconsistent indentation: line mixes tabs and spaces.",
                        line=idx,
                        column=1,
                        source_snippet=line,
                        category="token",
                        severity="error",
                        details={"issue": "mixed_tabs_spaces"},
                    )
                )

        bracket_stack: list[tuple[str, int, int]] = []  # (char, line, col)
        stream = io.StringIO(code)

        try:
            for tok in tokenize.generate_tokens(stream.readline):
                tok_type = tok.type
                tok_str = tok.string
                srow, scol = tok.start

                if tok_type == token.OP:
                    if tok_str in cls.BRACKET_PAIRS:
                        bracket_stack.append((tok_str, srow, scol + 1))
                    elif tok_str in cls.REVERSE_BRACKET_PAIRS:
                        expected_open = cls.REVERSE_BRACKET_PAIRS[tok_str]
                        if not bracket_stack:
                            line_content = lines[srow - 1] if srow <= len(lines) else ""
                            errors.append(
                                DetectedError(
                                    error_type="SyntaxError",
                                    message=f"Unmatched closing bracket '{tok_str}' with no matching opening '{expected_open}'.",
                                    line=srow,
                                    column=scol + 1,
                                    source_snippet=line_content,
                                    category="token",
                                    severity="error",
                                    details={"issue": "unmatched_closing", "bracket": tok_str},
                                )
                            )
                        else:
                            last_open, last_row, last_col = bracket_stack.pop()
                            if last_open != expected_open:
                                line_content = lines[srow - 1] if srow <= len(lines) else ""
                                errors.append(
                                    DetectedError(
                                        error_type="SyntaxError",
                                        message=f"Mismatched bracket: expected '{cls.BRACKET_PAIRS[last_open]}' to close '{last_open}' from line {last_row}, but found '{tok_str}'.",
                                        line=srow,
                                        column=scol + 1,
                                        source_snippet=line_content,
                                        category="token",
                                        severity="error",
                                        details={
                                            "issue": "mismatched_brackets",
                                            "opened": last_open,
                                            "opened_line": last_row,
                                            "closed": tok_str,
                                        },
                                    )
                                )

            # If unclosed brackets remain in the stack
            for unclosed, urow, ucol in bracket_stack:
                closing = cls.BRACKET_PAIRS[unclosed]
                bracket_name = {
                    "(": "parenthesis ')'",
                    "[": "square bracket ']'",
                    "{": "curly brace '}'",
                }.get(unclosed, f"'{closing}'")
                line_content = lines[urow - 1] if urow <= len(lines) else ""
                errors.append(
                    DetectedError(
                        error_type="SyntaxError",
                        message=f"Missing closing {bracket_name} opened at line {urow}, column {ucol}.",
                        line=urow,
                        column=ucol,
                        source_snippet=line_content,
                        category="token",
                        severity="error",
                        details={
                            "issue": "unclosed_bracket",
                            "bracket": unclosed,
                            "expected": closing,
                            "open_line": urow,
                            "open_col": ucol,
                        },
                    )
                )

        except tokenize.TokenError as exc:
            msg, (erow, ecol) = exc.args
            line_content = lines[erow - 1] if 1 <= erow <= len(lines) else ""
            msg_lower = msg.lower()
            if bracket_stack and "multi-line statement" in msg:
                # If we have unclosed brackets on the stack, report them using their exact opening lines!
                for unclosed, urow, ucol in bracket_stack:
                    closing = cls.BRACKET_PAIRS[unclosed]
                    bracket_name = {
                        "(": "parenthesis ')'",
                        "[": "square bracket ']'",
                        "{": "curly brace '}'",
                    }.get(unclosed, f"'{closing}'")
                    err_snippet = lines[urow - 1] if urow <= len(lines) else ""
                    errors.append(
                        DetectedError(
                            error_type="SyntaxError",
                            message=f"Missing closing {bracket_name} opened at line {urow}, column {ucol}.",
                            line=urow,
                            column=ucol,
                            source_snippet=err_snippet,
                            category="token",
                            severity="error",
                            details={
                                "issue": "unclosed_bracket",
                                "bracket": unclosed,
                                "expected": closing,
                                "open_line": urow,
                                "open_col": ucol,
                            },
                        )
                    )
            elif (
                "unterminated string literal" in msg_lower
                or "unterminated triple-quoted string" in msg_lower
                or "eof in multi-line string" in msg_lower
                or "eol while scanning string literal" in msg_lower
            ):
                det_line = erow
                match_det = re.search(r"detected at line (\d+)", msg)
                if match_det:
                    det_line = int(match_det.group(1))

                target_line = lines[det_line - 1] if 1 <= det_line <= len(lines) else line_content

                # Inspect target line for unclosed quotes
                quote_char = None
                open_col = ecol or 1
                i = 0
                while i < len(target_line):
                    ch = target_line[i]
                    if ch == "\\" and quote_char:
                        i += 2
                        continue
                    if ch in ('"', "'"):
                        if i + 2 < len(target_line) and target_line[i : i + 3] == ch * 3:
                            q = ch * 3
                            if quote_char == q:
                                quote_char = None
                            elif quote_char is None:
                                quote_char = q
                                open_col = i + 1
                            i += 3
                            continue
                        if quote_char == ch:
                            quote_char = None
                        elif quote_char is None:
                            quote_char = ch
                            open_col = i + 1
                    i += 1

                q_name = (
                    "double quote ('\"')"
                    if quote_char in ('"', '"""')
                    else ("single quote ('\\'')" if quote_char in ("'", "'''") else "quotation mark")
                )

                errors.append(
                    DetectedError(
                        error_type="SyntaxError",
                        message=f"Unterminated string literal: string opened with {q_name} at line {det_line}, column {open_col} was not closed.",
                        line=det_line,
                        column=open_col,
                        source_snippet=target_line,
                        category="token",
                        severity="error",
                        details={
                            "issue": "unclosed_string",
                            "quote": quote_char or ('"' if '"' in target_line else "'"),
                            "open_line": det_line,
                            "open_col": open_col,
                            "raw_message": msg,
                        },
                    )
                )
            elif "EOF in multi-line statement" in msg:
                errors.append(
                    DetectedError(
                        error_type="SyntaxError",
                        message="Unclosed bracket, parenthesis, or statement at end of code.",
                        line=erow,
                        column=ecol or 1,
                        source_snippet=line_content,
                        category="token",
                        severity="error",
                        details={"issue": "unclosed_statement", "raw_message": msg},
                    )
                )
            else:
                errors.append(
                    DetectedError(
                        error_type="SyntaxError",
                        message=f"Tokenization error: {msg}.",
                        line=erow,
                        column=ecol or 1,
                        source_snippet=line_content,
                        category="token",
                        severity="error",
                        details={"issue": "token_error", "raw_message": msg},
                    )
                )
        except IndentationError as exc:
            line_content = lines[exc.lineno - 1] if exc.lineno and 1 <= exc.lineno <= len(lines) else ""
            errors.append(
                DetectedError(
                    error_type="IndentationError",
                    message=f"Indentation error: {exc.msg}.",
                    line=exc.lineno or 1,
                    column=exc.offset or 1,
                    source_snippet=line_content,
                    category="token",
                    severity="error",
                    details={"issue": "indentation_error"},
                )
            )

        return errors


class StaticASTAnalyzer(ast.NodeVisitor):
    """Static AST visitor for semantic checks: undefined variables, bad operations, arg mismatches, logical issues."""

    BUILTIN_NAMES = set(dir(builtins))

    def __init__(self, code: str):
        self.code = code
        self.lines = code.splitlines()
        self.errors: List[DetectedError] = []
        self.scope_stack: list[dict[str, Any]] = [{"defined": set(self.BUILTIN_NAMES), "assigned": set()}]
        self.function_defs: dict[str, tuple[list[str], int]] = {}  # name -> (args, line)

    def _get_line(self, lineno: int) -> str:
        return self.lines[lineno - 1] if 1 <= lineno <= len(self.lines) else ""

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            name = alias.asname or alias.name.split(".")[0]
            self.scope_stack[-1]["defined"].add(name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        for alias in node.names:
            name = alias.asname or alias.name
            self.scope_stack[-1]["defined"].add(name)
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.scope_stack[-1]["defined"].add(node.name)
        arg_names = [a.arg for a in node.args.args]
        self.function_defs[node.name] = (arg_names, node.lineno)

        # Check for mutable default arguments
        for default in node.args.defaults:
            if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                self.errors.append(
                    DetectedError(
                        error_type="LogicalWarning",
                        message=f"Mutable default argument '{ast.unparse(default)}' in function '{node.name}'. Use None and default in body.",
                        line=node.lineno,
                        column=node.col_offset + 1,
                        source_snippet=self._get_line(node.lineno),
                        category="logical",
                        severity="warning",
                        details={"issue": "mutable_default", "function": node.name},
                    )
                )

        # Enter new function scope
        new_scope = {"defined": set(self.BUILTIN_NAMES) | set(arg_names), "assigned": set(arg_names)}
        self.scope_stack.append(new_scope)
        self.generic_visit(node)
        self.scope_stack.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.scope_stack[-1]["defined"].add(node.name)
        arg_names = [a.arg for a in node.args.args]
        self.function_defs[node.name] = (arg_names, node.lineno)
        new_scope = {"defined": set(self.BUILTIN_NAMES) | set(arg_names), "assigned": set(arg_names)}
        self.scope_stack.append(new_scope)
        self.generic_visit(node)
        self.scope_stack.pop()

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.scope_stack[-1]["defined"].add(node.name)
        new_scope = {"defined": set(self.BUILTIN_NAMES), "assigned": set()}
        self.scope_stack.append(new_scope)
        self.generic_visit(node)
        self.scope_stack.pop()

    def visit_Assign(self, node: ast.Assign) -> None:
        # First visit the right-hand value so we detect undefined variables used in assignment
        self.visit(node.value)
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.scope_stack[-1]["defined"].add(target.id)
                self.scope_stack[-1]["assigned"].add(target.id)
            elif isinstance(target, (ast.Tuple, ast.List)):
                for elt in target.elts:
                    if isinstance(elt, ast.Name):
                        self.scope_stack[-1]["defined"].add(elt.id)
                        self.scope_stack[-1]["assigned"].add(elt.id)
            else:
                self.visit(target)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value:
            self.visit(node.value)
        if isinstance(node.target, ast.Name):
            self.scope_stack[-1]["defined"].add(node.target.id)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self.visit(node.target)
        self.visit(node.value)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load):
            is_defined = any(node.id in s["defined"] for s in reversed(self.scope_stack))
            if not is_defined:
                self.errors.append(
                    DetectedError(
                        error_type="NameError",
                        message=f"Undefined variable or name '{node.id}' is used before definition.",
                        line=node.lineno,
                        column=node.col_offset + 1,
                        source_snippet=self._get_line(node.lineno),
                        category="ast_static",
                        severity="error",
                        details={"name": node.id, "issue": "undefined_variable"},
                    )
                )

    def visit_BinOp(self, node: ast.BinOp) -> None:
        # Check for division by literal zero
        if isinstance(node.op, (ast.Div, ast.FloorDiv, ast.Mod)):
            if isinstance(node.right, ast.Constant) and node.right.value == 0:
                self.errors.append(
                    DetectedError(
                        error_type="ZeroDivisionError",
                        message="Division or modulo by literal zero detected.",
                        line=node.lineno,
                        column=node.col_offset + 1,
                        source_snippet=self._get_line(node.lineno),
                        category="ast_static",
                        severity="error",
                        details={"issue": "zero_division"},
                    )
                )

        # Check for literal string + int addition
        if isinstance(node.op, ast.Add):
            left_val = node.left.value if isinstance(node.left, ast.Constant) else None
            right_val = node.right.value if isinstance(node.right, ast.Constant) else None
            if (isinstance(left_val, str) and isinstance(right_val, (int, float))) or (
                isinstance(left_val, (int, float)) and isinstance(right_val, str)
            ):
                self.errors.append(
                    DetectedError(
                        error_type="TypeError",
                        message=f"Cannot add mismatched literal types: '{type(left_val).__name__}' and '{type(right_val).__name__}'.",
                        line=node.lineno,
                        column=node.col_offset + 1,
                        source_snippet=self._get_line(node.lineno),
                        category="ast_static",
                        severity="error",
                        details={"issue": "mismatched_binary_operands", "types": [type(left_val).__name__, type(right_val).__name__]},
                    )
                )

        self.generic_visit(node)

    def visit_Compare(self, node: ast.Compare) -> None:
        # Check for comparison with literal using 'is'
        for op, comp in zip(node.ops, node.comparators):
            if isinstance(op, (ast.Is, ast.IsNot)):
                if isinstance(comp, ast.Constant) and isinstance(comp.value, (int, float, str)):
                    self.errors.append(
                        DetectedError(
                            error_type="LogicalWarning",
                            message=f"Comparison with literal using '{'is' if isinstance(op, ast.Is) else 'is not'}'. Use '==' or '!=' instead.",
                            line=node.lineno,
                            column=node.col_offset + 1,
                            source_snippet=self._get_line(node.lineno),
                            category="logical",
                            severity="warning",
                            details={"issue": "is_literal_comparison"},
                        )
                    )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        # Check call arguments count against known locally defined functions
        if isinstance(node.func, ast.Name) and node.func.id in self.function_defs:
            arg_names, def_line = self.function_defs[node.func.id]
            expected_count = len(arg_names)
            passed_count = len(node.args)
            if passed_count > expected_count:
                self.errors.append(
                    DetectedError(
                        error_type="TypeError",
                        message=f"Function '{node.func.id}' defined on line {def_line} expects {expected_count} argument(s), but {passed_count} were passed.",
                        line=node.lineno,
                        column=node.col_offset + 1,
                        source_snippet=self._get_line(node.lineno),
                        category="ast_static",
                        severity="error",
                        details={
                            "issue": "too_many_arguments",
                            "function": node.func.id,
                            "expected": expected_count,
                            "passed": passed_count,
                        },
                    )
                )

        self.generic_visit(node)


class ErrorDetector:
    """Primary Error Detection System combining AST, Tokenize, and Traceback parsing."""

    CONTROL_KEYWORDS = (
        "if", "elif", "else", "for", "while", "def", "class",
        "try", "except", "finally", "with", "async def", "async for", "async with", "match", "case"
    )

    @classmethod
    def detect_static(cls, code: str) -> List[DetectedError]:
        """Detect static syntax, token, and semantic errors without running the code."""
        if not code or not code.strip():
            return []

        errors: List[DetectedError] = []

        # 1. Token-level analysis (brackets, quotes, tabs)
        token_errors = TokenAnalyzer.analyze(code)
        errors.extend(token_errors)

        # 2. Syntax / AST parse attempt
        lines = code.splitlines()
        try:
            tree = ast.parse(code, filename="<seds_editor>")
            # 3. If parsing succeeded, run static AST semantic checks
            visitor = StaticASTAnalyzer(code)
            visitor.visit(tree)
            errors.extend(visitor.errors)

        except SyntaxError as exc:
            # Check for missing colon on compound statements
            line_no = exc.lineno or 1
            col_no = exc.offset or 1
            snippet = lines[line_no - 1] if 1 <= line_no <= len(lines) else (exc.text or "").strip()

            specific_message = exc.msg
            error_type = exc.__class__.__name__

            # Check if this is a missing colon issue
            is_colon_issue = False
            stripped = snippet.strip()
            for kw in cls.CONTROL_KEYWORDS:
                if re.match(rf"^{kw}\b", stripped) and not stripped.endswith(":"):
                    specific_message = f"Missing colon ':' at the end of '{kw}' statement."
                    is_colon_issue = True
                    break

            # Avoid duplicate bracket errors if token analyzer already caught it
            has_matching_token_err = any(
                e.line == line_no and e.category == "token" for e in token_errors
            )

            if not has_matching_token_err:
                errors.append(
                    DetectedError(
                        error_type=error_type,
                        message=specific_message,
                        line=line_no,
                        column=col_no,
                        end_line=exc.end_lineno,
                        end_column=exc.end_offset,
                        source_snippet=snippet,
                        category="syntax",
                        severity="error",
                        details={
                            "issue": "missing_colon" if is_colon_issue else "syntax_error",
                            "raw_message": exc.msg,
                        },
                    )
                )

        return errors

    @classmethod
    def parse_runtime_traceback(cls, stderr: str, source_code: str = "") -> Optional[DetectedError]:
        """Parse runtime traceback from stderr and map directly to user source code."""
        if not stderr or not stderr.strip():
            return None

        lines = stderr.strip().splitlines()
        source_lines = source_code.splitlines() if source_code else []

        # Look for the last frame corresponding to user code (<seds_runner> or temp file)
        user_line_no: Optional[int] = None
        user_col_no: Optional[int] = None

        for idx, line in enumerate(lines):
            match = re.search(r'File ".*?", line (\d+)(?:, in .*)?', line)
            if match:
                user_line_no = int(match.group(1))

        # Check for column caret in Python 3.11+ (e.g. "~~~~~^~~~~~")
        for line in lines:
            if re.match(r"^\s*[\^~]+\s*$", line):
                user_col_no = line.find("^") + 1
                break

        # Extract exception line (usually last line)
        last_line = lines[-1].strip()
        error_type = "RuntimeError"
        error_msg = last_line

        # Match "ExceptionType: details"
        match = re.match(r"^([A-Za-z_][A-Za-z0-9_.]*):\s*(.*)$", last_line)
        if match:
            error_type = match.group(1)
            error_msg = match.group(2)
        elif "SyntaxError" in last_line:
            error_type = "SyntaxError"

        line_num = user_line_no or 1
        snippet = source_lines[line_num - 1] if source_lines and 1 <= line_num <= len(source_lines) else ""

        return DetectedError(
            error_type=error_type,
            message=error_msg,
            line=line_num,
            column=user_col_no or 1,
            source_snippet=snippet,
            category="runtime",
            severity="error",
            details={"raw_stderr": stderr},
        )

    @classmethod
    def detect_all(cls, code: str, runtime_stderr: Optional[str] = None) -> List[DetectedError]:
        """Comprehensive error detection merging static and runtime findings."""
        errors = cls.detect_static(code)

        if runtime_stderr:
            runtime_err = cls.parse_runtime_traceback(runtime_stderr, code)
            if runtime_err:
                # Check if static analysis already pinpointed the exact same line and error type
                already_exists = any(
                    e.line == runtime_err.line and e.error_type == runtime_err.error_type
                    for e in errors
                )
                if not already_exists:
                    # Put runtime error at front since it halted execution
                    errors.insert(0, runtime_err)

        return errors
