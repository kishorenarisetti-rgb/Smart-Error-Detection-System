"""SEDS Automatic Code Repair Engine.

Generates, validates, and diffs candidate code fixes:
- Synthesizes precise syntax repairs (missing brackets, colons, quotes).
- Fixes IndentationError and TabError by normalizing spaces.
- Identifies and replaces misspelled variables/builtins in NameError.
- Guards divisions against ZeroDivisionError.
- Leverages AI suggestions when user consent is provided.
- Strictly validates candidates using AST / compile before offering them.
- Produces unified diffs comparing original and corrected code.
- Ensures program logic is preserved without inventing arbitrary values.
"""

from __future__ import annotations

import ast
import difflib
import re
from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional

from backend.ai_service import AIService
from backend.detector import DetectedError


@dataclass
class FixResult:
    is_valid: bool
    original_code: str
    fixed_code: Optional[str]
    diff: str
    changes_description: str
    requires_user_review: bool = False
    validation_notes: str = ""
    provider: str = "local_rule_engine"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AutoFixer:
    """Intelligent repair engine that generates and validates code patches."""

    @classmethod
    def generate_fix(
        cls,
        error: DetectedError,
        source_code: str,
        user_consent: bool = False,
        preferred_provider: str = "auto",
    ) -> FixResult:
        """Attempt to generate a validated fix, using AI if consented, or local heuristics."""
        # 1. If AI is authorized, try AI fix first
        if user_consent:
            ai_data = AIService.explain_and_fix(
                error.to_dict(), source_code, user_consent=True, preferred_provider=preferred_provider
            )
            if ai_data and ai_data.get("corrected_code") and not ai_data.get("fallback"):
                candidate = ai_data["corrected_code"].strip()
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    diff_text = cls._create_diff(source_code, candidate)
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=diff_text,
                        changes_description=ai_data.get("how_to_fix", "AI generated automatic fix."),
                        requires_user_review=ai_data.get("confidence") != "High",
                        validation_notes="Passed Python syntax and AST compilation checks.",
                        provider="ai",
                    )

        # 2. Local rule-based repair engine
        return cls._generate_local_fix(error, source_code)

    @classmethod
    def validate_candidate(cls, candidate: str) -> tuple[bool, str]:
        """Validate candidate code by parsing AST and compiling."""
        if not candidate or not candidate.strip():
            return False, "Candidate code is empty."
        try:
            ast.parse(candidate, filename="<seds_candidate>")
            compile(candidate, "<seds_candidate>", "exec")
            return True, "Code passed AST and compile validation successfully."
        except (SyntaxError, ValueError) as exc:
            return False, f"Syntax validation failed: {exc}"

    @classmethod
    def _create_diff(cls, original: str, fixed: str) -> str:
        orig_lines = original.splitlines(keepends=True)
        fixed_lines = fixed.splitlines(keepends=True)
        diff = difflib.unified_diff(
            orig_lines,
            fixed_lines,
            fromfile="Original Code",
            tofile="Suggested Fix",
            lineterm="",
        )
        return "".join(diff)

    @classmethod
    def _fix_unclosed_string(
        cls,
        source_code: str,
        line_idx: int,
        quote_hint: Optional[str] = None,
    ) -> Optional[tuple[str, str]]:
        lines = source_code.splitlines()
        if not (0 <= line_idx < len(lines)):
            return None
        target = lines[line_idx]

        quotes_to_try: list[str] = []
        if quote_hint in ('"', "'", '"""', "'''"):
            quotes_to_try.append(quote_hint)
        if target.count('"') % 2 != 0:
            quotes_to_try.append('"')
        if target.count("'") % 2 != 0:
            quotes_to_try.append("'")
        for q in ('"', "'"):
            if q not in quotes_to_try:
                quotes_to_try.append(q)

        candidates: list[tuple[str, str]] = []
        for q in quotes_to_try:
            # Candidate A: Insert quote before trailing closing delimiters (e.g. `)` in `print("hello)`)
            match_trailing = re.search(r"([\s,;:)}\]]+)$", target)
            if match_trailing:
                pos = match_trailing.start()
                cand_line = target[:pos] + q + target[pos:]
                candidates.append((cand_line, f"Closed string literal with {q} before trailing delimiter."))

            # Candidate B: Append quote at end of stripped line (e.g. `name = 'Kishore`)
            cand_line_end = target.rstrip() + q
            candidates.append((cand_line_end, f"Added missing closing quote {q} at end of statement."))

            # Candidate C: Insert quote and close any open brackets from this line
            # (e.g. `print("Hello` -> missing `"` and missing `)`)
            open_parens = max(0, target.count("(") - target.count(")"))
            open_squares = max(0, target.count("[") - target.count("]"))
            open_curlies = max(0, target.count("{") - target.count("}"))
            brackets = (")" * open_parens) + ("]" * open_squares) + ("}" * open_curlies)
            if brackets:
                cand_combined = target.rstrip() + q + brackets
                candidates.append((cand_combined, f"Closed string with {q} and completed matching brackets."))

            # Candidate D: Before each closing delimiter or comma scanning from right to left
            for idx in range(len(target) - 1, -1, -1):
                if target[idx] in (")", "]", "}", ",", ":"):
                    cand_mid = target[:idx] + q + target[idx:]
                    candidates.append((cand_mid, f"Closed string with {q}."))

        # Validate candidates using Python AST parser
        for cand_line, desc in candidates:
            cand_lines = list(lines)
            cand_lines[line_idx] = cand_line
            candidate_code = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
            val_ok, note = cls.validate_candidate(candidate_code)
            if val_ok:
                return candidate_code, desc

        return None

    @classmethod
    def _generate_local_fix(cls, error: DetectedError, source_code: str) -> FixResult:
        lines = source_code.splitlines()
        line_idx = error.line - 1 if 1 <= error.line <= len(lines) else None

        # Case 1: IndentationError / TabError -> Expand tabs to 4 spaces
        if error.error_type in ("IndentationError", "TabError") or (error.details and error.details.get("issue") == "mixed_tabs_spaces"):
            candidate = source_code.expandtabs(4)
            if candidate != source_code:
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description="Normalized tab indentation to consistent 4 spaces.",
                        requires_user_review=False,
                        validation_notes=note,
                    )

        # Case 2: Missing closing bracket
        if error.details and error.details.get("issue") in ("unclosed_bracket", "unclosed_statement") and line_idx is not None:
            expected_char = error.details.get("expected")
            if not expected_char and "bracket" in error.message.lower():
                if "square" in error.message.lower() or "[" in error.source_snippet:
                    expected_char = "]"
                elif "curly" in error.message.lower() or "{" in error.source_snippet:
                    expected_char = "}"
                else:
                    expected_char = ")"

            if expected_char:
                candidate_lines = list(lines)
                candidate_lines[line_idx] = candidate_lines[line_idx] + expected_char
                candidate = "\n".join(candidate_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Appended missing closing bracket '{expected_char}' on line {error.line}.",
                        requires_user_review=False,
                        validation_notes=note,
                    )

        # Case 3: Missing colon on compound statement
        if (error.details and error.details.get("issue") == "missing_colon" or "colon" in error.message.lower()) and line_idx is not None:
            target = lines[line_idx].rstrip()
            if not target.endswith(":"):
                candidate_lines = list(lines)
                candidate_lines[line_idx] = target + ":"
                candidate = "\n".join(candidate_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Added missing colon ':' to block header on line {error.line}.",
                        requires_user_review=False,
                        validation_notes=note,
                    )

        # Case 4: Missing closing quote in string literal (unterminated string literal)
        is_string_err = (
            (error.details and error.details.get("issue") == "unclosed_string")
            or "unterminated string" in error.message.lower()
            or "unclosed string" in error.message.lower()
            or "quotation mark" in error.message.lower()
            or (error.details and "unterminated string" in str(error.details.get("raw_message", "")).lower())
        )
        if is_string_err and line_idx is not None:
            quote_hint = error.details.get("quote") if error.details else None
            fix_res = cls._fix_unclosed_string(source_code, line_idx, quote_hint)
            if fix_res:
                fixed_code, desc = fix_res
                return FixResult(
                    is_valid=True,
                    original_code=source_code,
                    fixed_code=fixed_code,
                    diff=cls._create_diff(source_code, fixed_code),
                    changes_description=desc,
                    requires_user_review=False,
                    validation_notes="Code passed AST and compile validation successfully.",
                )

        # Case 5: NameError - missing import or misspelled identifier
        if error.error_type == "NameError" and line_idx is not None:
            unknown_name = None
            if error.details and "name" in error.details:
                unknown_name = error.details["name"]
            else:
                match = re.search(r"name ['\"]([^'\"]+)['\"]", error.message)
                if match:
                    unknown_name = match.group(1)

            COMMON_STDLIB = {
                "math", "sys", "os", "json", "random", "re", "time", "datetime",
                "pathlib", "collections", "itertools", "functools", "urllib", "sqlite3",
                "csv", "hashlib", "copy", "shutil", "io", "string", "subprocess", "logging"
            }
            if unknown_name in COMMON_STDLIB:
                candidate = f"import {unknown_name}\n" + source_code
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Added missing standard library import 'import {unknown_name}'.",
                        requires_user_review=False,
                        validation_notes=note,
                    )

            if unknown_name:
                identifiers = set(re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", source_code))
                import builtins
                identifiers.update(dir(builtins))
                identifiers.discard(unknown_name)
                close_matches = difflib.get_close_matches(unknown_name, sorted(identifiers), n=1, cutoff=0.7)
                if close_matches:
                    replacement = close_matches[0]
                    target_line = lines[line_idx]
                    corrected_line = re.sub(rf"\b{re.escape(unknown_name)}\b", replacement, target_line, count=1)
                    candidate_lines = list(lines)
                    candidate_lines[line_idx] = corrected_line
                    candidate = "\n".join(candidate_lines) + ("\n" if source_code.endswith("\n") else "")
                    val_ok, note = cls.validate_candidate(candidate)
                    if val_ok:
                        return FixResult(
                            is_valid=True,
                            original_code=source_code,
                            fixed_code=candidate,
                            diff=cls._create_diff(source_code, candidate),
                            changes_description=f"Corrected likely misspelled name '{unknown_name}' to '{replacement}' on line {error.line}.",
                            requires_user_review=False,
                            validation_notes=note,
                        )

        # Case 6: SyntaxError - Assignment in condition (if x = 5 -> if x == 5)
        if error.error_type == "SyntaxError" and line_idx is not None:
            target = lines[line_idx]
            match_assign = re.search(r"^(?P<indent>\s*(?:if|elif|while)\s+)(?P<expr>[^=:\n]+)=(?P<rest>[^=:\n]+:.*)$", target)
            if match_assign:
                corrected_line = match_assign.group("indent") + match_assign.group("expr").rstrip() + " == " + match_assign.group("rest").lstrip()
                cand_lines = list(lines)
                cand_lines[line_idx] = corrected_line
                candidate = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Replaced assignment '=' with comparison '==' in condition on line {error.line}.",
                        requires_user_review=False,
                        validation_notes=note,
                    )

        # Case 7: SyntaxError - C-style logical operators (&&, ||, ===, !==, true, false, null)
        if error.error_type == "SyntaxError" and line_idx is not None:
            target = lines[line_idx]
            corrected = target
            corrected = re.sub(r"===+", "==", corrected)
            corrected = re.sub(r"!==+", "!=", corrected)
            corrected = re.sub(r"\s*&&\s*", " and ", corrected)
            corrected = re.sub(r"\s*\|\|\s*", " or ", corrected)
            corrected = re.sub(r"\btrue\b", "True", corrected)
            corrected = re.sub(r"\bfalse\b", "False", corrected)
            corrected = re.sub(r"\bnull\b", "None", corrected)
            if corrected != target:
                cand_lines = list(lines)
                cand_lines[line_idx] = corrected
                candidate = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Converted C-style logical operators to Python equivalents ('and', 'or', '==') on line {error.line}.",
                        requires_user_review=False,
                        validation_notes=note,
                    )

        # Case 8: SyntaxError - Python 2 style print statement without parens
        if error.error_type == "SyntaxError" and line_idx is not None:
            target = lines[line_idx]
            match_print = re.match(r"^(?P<indent>\s*)print\s+(?P<args>[^()]+)$", target)
            if match_print:
                corrected_line = f"{match_print.group('indent')}print({match_print.group('args').strip()})"
                cand_lines = list(lines)
                cand_lines[line_idx] = corrected_line
                candidate = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Wrapped print statement arguments in parentheses on line {error.line}.",
                        requires_user_review=False,
                        validation_notes=note,
                    )

        # Case 9: ZeroDivisionError
        if error.error_type == "ZeroDivisionError" and line_idx is not None:
            target_line = lines[line_idx]
            match = re.search(r"(?P<num>[A-Za-z0-9_.]+)\s*/\s*(?P<denom>[A-Za-z0-9_.]+)", target_line)
            if match:
                num = match.group("num")
                denom = match.group("denom")
                safe_expr = f"({num} / {denom} if {denom} != 0 else 0)"
                corrected_line = target_line[: match.start()] + safe_expr + target_line[match.end() :]
                candidate_lines = list(lines)
                candidate_lines[line_idx] = corrected_line
                candidate = "\n".join(candidate_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Guarded division against zero on line {error.line} (returns 0 if denominator is 0).",
                        requires_user_review=True,
                        validation_notes="Please confirm whether returning 0 when divisor is zero matches your application logic.",
                    )

        # Case 10: TypeError - string concatenation with int/float
        if error.error_type == "TypeError" and line_idx is not None:
            target = lines[line_idx]
            if "can only concatenate str" in error.message or "unsupported operand type(s) for +" in error.message:
                match_plus = re.search(r"(\+\s*)([A-Za-z_][A-Za-z0-9_.]*)", target)
                if match_plus:
                    prefix = target[: match_plus.start()]
                    var = match_plus.group(2)
                    suffix = target[match_plus.end() :]
                    corrected_line = f"{prefix}+ str({var}){suffix}"
                    cand_lines = list(lines)
                    cand_lines[line_idx] = corrected_line
                    candidate = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
                    val_ok, note = cls.validate_candidate(candidate)
                    if val_ok:
                        return FixResult(
                            is_valid=True,
                            original_code=source_code,
                            fixed_code=candidate,
                            diff=cls._create_diff(source_code, candidate),
                            changes_description=f"Wrapped non-string variable '{var}' in str() for safe concatenation on line {error.line}.",
                            requires_user_review=False,
                            validation_notes=note,
                        )

        # Case 11: KeyError - dictionary key lookup
        if error.error_type == "KeyError" and line_idx is not None:
            target = lines[line_idx]
            match_key = re.search(r"(\b[A-Za-z_][A-Za-z0-9_.]*)\[(['\"][^'\"]+['\"])\]", target)
            if match_key:
                dict_name = match_key.group(1)
                key_expr = match_key.group(2)
                replacement = f"{dict_name}.get({key_expr})"
                corrected_line = target[: match_key.start()] + replacement + target[match_key.end() :]
                cand_lines = list(lines)
                cand_lines[line_idx] = corrected_line
                candidate = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Replaced direct dictionary key lookup {dict_name}[{key_expr}] with safe {dict_name}.get({key_expr}) on line {error.line}.",
                        requires_user_review=True,
                        validation_notes="Returns None instead of raising KeyError if key is missing.",
                    )

        # Case 12: IndexError - list index out of range
        if error.error_type == "IndexError" and line_idx is not None:
            target = lines[line_idx]
            match_idx = re.search(r"(\b[A-Za-z_][A-Za-z0-9_.]*)\[([A-Za-z0-9_.]+)\]", target)
            if match_idx:
                list_name = match_idx.group(1)
                idx_expr = match_idx.group(2)
                safe_expr = f"({list_name}[{idx_expr}] if len({list_name}) > {idx_expr} else None)"
                corrected_line = target[: match_idx.start()] + safe_expr + target[match_idx.end() :]
                cand_lines = list(lines)
                cand_lines[line_idx] = corrected_line
                candidate = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
                val_ok, note = cls.validate_candidate(candidate)
                if val_ok:
                    return FixResult(
                        is_valid=True,
                        original_code=source_code,
                        fixed_code=candidate,
                        diff=cls._create_diff(source_code, candidate),
                        changes_description=f"Added bounds check guard for {list_name}[{idx_expr}] on line {error.line}.",
                        requires_user_review=True,
                        validation_notes="Guards against IndexError by validating index against list length.",
                    )

        # Case 13: AttributeError - misspelled method or attribute
        if error.error_type == "AttributeError" and line_idx is not None:
            target = lines[line_idx]
            match_attr = re.search(r"object has no attribute ['\"]([^'\"]+)['\"]", error.message)
            if match_attr:
                unknown_attr = match_attr.group(1)
                KNOWN_METHODS = [
                    "append", "extend", "insert", "remove", "pop", "clear", "index", "count",
                    "sort", "reverse", "copy", "strip", "lstrip", "rstrip", "lower", "upper",
                    "capitalize", "title", "replace", "split", "rsplit", "join", "find",
                    "rfind", "startswith", "endswith", "isalpha", "isdigit", "isalnum",
                    "keys", "values", "items", "get", "update", "setdefault", "add", "discard"
                ]
                matches = difflib.get_close_matches(unknown_attr, KNOWN_METHODS, n=1, cutoff=0.6)
                if matches:
                    replacement = matches[0]
                    corrected_line = re.sub(rf"\b{re.escape(unknown_attr)}\b", replacement, target, count=1)
                    cand_lines = list(lines)
                    cand_lines[line_idx] = corrected_line
                    candidate = "\n".join(cand_lines) + ("\n" if source_code.endswith("\n") else "")
                    val_ok, note = cls.validate_candidate(candidate)
                    if val_ok:
                        return FixResult(
                            is_valid=True,
                            original_code=source_code,
                            fixed_code=candidate,
                            diff=cls._create_diff(source_code, candidate),
                            changes_description=f"Corrected misspelled method '.{unknown_attr}' to '.{replacement}' on line {error.line}.",
                            requires_user_review=False,
                            validation_notes=note,
                        )

        # If no deterministic automated fix can be guaranteed safely
        return FixResult(
            is_valid=False,
            original_code=source_code,
            fixed_code=None,
            diff="",
            changes_description="Automatic repair could not infer developer intent with 100% certainty.",
            requires_user_review=True,
            validation_notes="Please consult the 7-point AI Error Explanation to make the manual adjustment.",
        )
