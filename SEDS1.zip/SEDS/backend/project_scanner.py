"""SEDS Project Scanner Module.

Scans multi-file Python codebases:
- Recursively discovers all .py files while ignoring irrelevant virtual environments.
- Performs AST and Token-level error detection on each file.
- Aggregates error types, lines, snippets, and beginner-friendly explanations.
- Produces comprehensive scan reports (total files, passed, failed, duration).
- Strictly read-only: NEVER modifies project files during scanning.
"""

from __future__ import annotations

import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Set

from backend.detector import DetectedError, ErrorDetector
from backend.error_explainer import ErrorExplainer

EXCLUDED_DIRS: Set[str] = {
    ".git", ".venv", "venv", "__pycache__", "node_modules",
    ".idea", ".vscode", "build", "dist", ".pytest_cache", ".ruff_cache"
}


@dataclass
class FileScanResult:
    file_path: str
    relative_path: str
    status: str  # "PASS" | "ERROR" | "WARNING"
    error_count: int
    errors: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ProjectScanReport:
    folder_path: str
    total_files: int
    passed_files: int
    failed_files: int
    duration_ms: float
    files: List[FileScanResult]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "folder_path": self.folder_path,
            "total_files": self.total_files,
            "passed_files": self.passed_files,
            "failed_files": self.failed_files,
            "duration_ms": self.duration_ms,
            "files": [f.to_dict() for f in self.files],
        }


class ProjectScanner:
    """Recursively scans Python projects for syntax, token, and semantic issues."""

    @classmethod
    def scan_directory(cls, folder_path: str) -> ProjectScanReport:
        start_time = time.perf_counter()
        folder = Path(folder_path).resolve()

        if not folder.exists() or not folder.is_dir():
            raise ValueError(f"Directory not found or invalid: {folder_path}")

        file_results: List[FileScanResult] = []
        passed_count = 0
        failed_count = 0

        for root, dirs, filenames in os.walk(folder):
            # Prune excluded directories in-place
            dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]

            for fname in filenames:
                if not fname.endswith(".py"):
                    continue

                full_path = Path(root) / fname
                rel_path = str(full_path.relative_to(folder))

                try:
                    with open(full_path, "r", encoding="utf-8", errors="replace") as f:
                        content = f.read()

                    detected_errors: List[DetectedError] = ErrorDetector.detect_static(content)
                    has_errors = any(e.severity == "error" for e in detected_errors)

                    enriched_errors: List[Dict[str, Any]] = []
                    for err in detected_errors:
                        expl = ErrorExplainer.explain(err, content, user_consent=False)
                        item = err.to_dict()
                        item["explanation"] = expl.to_dict()
                        enriched_errors.append(item)

                    if has_errors:
                        failed_count += 1
                        status = "ERROR"
                    elif detected_errors:
                        passed_count += 1
                        status = "WARNING"
                    else:
                        passed_count += 1
                        status = "PASS"

                    file_results.append(
                        FileScanResult(
                            file_path=str(full_path),
                            relative_path=rel_path,
                            status=status,
                            error_count=len(enriched_errors),
                            errors=enriched_errors,
                        )
                    )

                except Exception as exc:
                    failed_count += 1
                    file_results.append(
                        FileScanResult(
                            file_path=str(full_path),
                            relative_path=rel_path,
                            status="ERROR",
                            error_count=1,
                            errors=[{
                                "error_type": "ReadError",
                                "message": f"Failed to read/scan file: {exc}",
                                "line": 1,
                                "column": 1,
                                "severity": "error",
                            }],
                        )
                    )

        duration = round((time.perf_counter() - start_time) * 1000, 2)
        return ProjectScanReport(
            folder_path=str(folder),
            total_files=len(file_results),
            passed_files=passed_count,
            failed_files=failed_count,
            duration_ms=duration,
            files=file_results,
        )
