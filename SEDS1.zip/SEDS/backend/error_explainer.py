"""SEDS Error Explainer Module.

Generates beginner-friendly explanations structured into 7 core dimensions:
1. What is the error?
2. Where did the error start?
3. Why did the error happen?
4. What caused the error?
5. Which part of the code is affected?
6. How can the developer fix it?
7. What is the corrected code?

Supports:
- High-quality local offline explanations for all 12 standard Python error types.
- AI-powered explanations via OpenAI/Gemini when configured and user gives consent.
"""

from __future__ import annotations

import difflib
import re
from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional

from backend.ai_service import AIService
from backend.detector import DetectedError


@dataclass
class ExplanationResult:
    what: str
    where: str
    why: str
    cause: str
    affected: str
    how_to_fix: str
    corrected_code: Optional[str] = None
    confidence: str = "High"
    provider: str = "local_heuristic"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ErrorExplainer:
    """Explains Python errors with 7-point beginner-friendly diagnostics."""

    @classmethod
    def explain(
        cls,
        error: DetectedError,
        source_code: str,
        user_consent: bool = False,
        preferred_provider: str = "auto",
    ) -> ExplanationResult:
        """Generate structured explanation using AI if authorized, or local heuristics."""
        # 1. Attempt AI explanation if consent is provided
        if user_consent:
            ai_data = AIService.explain_and_fix(
                error.to_dict(), source_code, user_consent=True, preferred_provider=preferred_provider
            )
            if ai_data and not ai_data.get("fallback"):
                return ExplanationResult(
                    what=ai_data.get("what", "Error detected in program execution."),
                    where=ai_data.get("where", f"Line {error.line}, Column {error.column}"),
                    why=ai_data.get("why", "The Python interpreter encountered an invalid instruction."),
                    cause=ai_data.get("cause", error.message),
                    affected=ai_data.get("affected", error.source_snippet or f"Line {error.line}"),
                    how_to_fix=ai_data.get("how_to_fix", "Review the suggested code fix."),
                    corrected_code=ai_data.get("corrected_code"),
                    confidence=ai_data.get("confidence", "High"),
                    provider=preferred_provider if preferred_provider != "auto" else "ai",
                )

        # 2. Local heuristic explanation fallback
        return cls._explain_locally(error, source_code)

    @classmethod
    def _explain_locally(cls, error: DetectedError, source_code: str) -> ExplanationResult:
        err_type = error.error_type
        msg = error.message
        line = error.line
        col = error.column
        snippet = error.source_snippet or (
            source_code.splitlines()[line - 1] if 1 <= line <= len(source_code.splitlines()) else ""
        )
        where = f"Line {line}, Column {col}"

        # 1. SyntaxError & Bracket/Token issues
        if err_type == "SyntaxError":
            if "bracket" in msg.lower() or "parenthesis" in msg.lower() or "brace" in msg.lower():
                return ExplanationResult(
                    what="SyntaxError: Unclosed or mismatched bracket/parenthesis.",
                    where=where,
                    why="Python needs matching opening and closing delimiters '()', '[]', or '{}'.",
                    cause=f"The bracket was opened but Python reached the end without finding the closing partner: {msg}",
                    affected=f"Expression on line {line}: `{snippet.strip()}`",
                    how_to_fix="Add the corresponding closing bracket at the end of the data structure or call.",
                    confidence="High",
                    provider="local_heuristic",
                )
            if "colon" in msg.lower() or "expected ':'" in msg.lower():
                return ExplanationResult(
                    what="SyntaxError: Missing colon (':') at the end of statement header.",
                    where=where,
                    why="In Python, compound statements (like if, for, while, def, class) must end with a colon ':' to introduce an indented block.",
                    cause=f"The line `{snippet.strip()}` is missing a ':' at the end.",
                    affected=f"Block header on line {line}: `{snippet.strip()}`",
                    how_to_fix="Add a colon ':' at the very end of this line.",
                    confidence="High",
                    provider="local_heuristic",
                )
            if "quotation mark" in msg.lower() or "string" in msg.lower() or (error.details and error.details.get("issue") == "unclosed_string"):
                q_char = error.details.get("quote", '"') if error.details else ('"' if '"' in snippet else "'")
                q_name = "double quote" if q_char in ('"', '"""') else "single quote"
                return ExplanationResult(
                    what="SyntaxError: Unterminated string literal.",
                    where=where,
                    why="String values must be enclosed in matching single ('') or double (\"\") quotes.",
                    cause=f"A string was opened with a {q_name} ({q_char}) but not properly closed.",
                    affected=f"String literal on line {line}: `{snippet.strip()}`",
                    how_to_fix=f"Add the closing {q_name} ({q_char}) before closing delimiters or at the end of the line.",
                    confidence="High",
                    provider="local_heuristic",
                )
            return ExplanationResult(
                what="SyntaxError: Invalid Python syntax.",
                where=where,
                why="The code violates Python grammar rules, so Python cannot parse or understand it.",
                cause=f"Python encountered an unexpected token or structure: {msg}",
                affected=f"Statement on line {line}: `{snippet.strip()}`",
                how_to_fix="Check for missing punctuation, improper operators, or misspelled keywords on this line.",
                confidence="High",
                provider="local_heuristic",
            )

        # 2. IndentationError & TabError
        if err_type in ("IndentationError", "TabError"):
            return ExplanationResult(
                what=f"{err_type}: Indentation problem in code block.",
                where=where,
                why="Python uses indentation (spacing) to determine which statements belong to which block or function.",
                cause="Inconsistent spaces/tabs or unexpected indentation level: " + msg,
                affected=f"Line {line}: `{snippet}`",
                how_to_fix="Use consistent 4 spaces per indentation level and avoid mixing tabs and spaces.",
                confidence="High",
                provider="local_heuristic",
            )

        # 3. NameError
        if err_type == "NameError":
            match = re.search(r"name ['\"]([^'\"]+)['\"]", msg)
            name = match.group(1) if match else "variable"
            # Try to find close matches for suggestions
            tokens = set(re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", source_code))
            tokens.discard(name)
            closest = difflib.get_close_matches(name, list(tokens), n=1, cutoff=0.7)
            fix_tip = (
                f"Did you mean '{closest[0]}' instead of '{name}'?"
                if closest
                else f"Define '{name}' before using it (e.g. `{name} = ...`) or verify spelling."
            )
            return ExplanationResult(
                what=f"NameError: Name '{name}' is not defined.",
                where=where,
                why="Python tried to evaluate an identifier that has not been assigned a value or imported.",
                cause=f"The variable or function '{name}' does not exist in the current scope.",
                affected=f"Usage of '{name}' on line {line}: `{snippet.strip()}`",
                how_to_fix=fix_tip,
                confidence="High",
                provider="local_heuristic",
            )

        # 4. TypeError
        if err_type == "TypeError":
            return ExplanationResult(
                what="TypeError: Incompatible data types in operation or function call.",
                where=where,
                why="The operation or function was invoked with values whose types are incompatible.",
                cause=msg,
                affected=f"Operation on line {line}: `{snippet.strip()}`",
                how_to_fix="Convert the operands to compatible types (e.g. using str() or int()) or check argument count.",
                confidence="High",
                provider="local_heuristic",
            )

        # 5. IndexError
        if err_type == "IndexError":
            return ExplanationResult(
                what="IndexError: Sequence index out of range.",
                where=where,
                why="You attempted to access an item at an index number that exceeds the length of the list/sequence.",
                cause="The list does not have an element at this position: " + msg,
                affected=f"Index access on line {line}: `{snippet.strip()}`",
                how_to_fix="Check `len(sequence)` before accessing, or verify zero-based indexing (remember index starts at 0).",
                confidence="High",
                provider="local_heuristic",
            )

        # 6. ZeroDivisionError
        if err_type == "ZeroDivisionError":
            return ExplanationResult(
                what="ZeroDivisionError: Division or modulo by zero.",
                where=where,
                why="In mathematics and computer science, dividing a number by zero is undefined.",
                cause="The denominator of a division ('/' or '//') or modulo ('%') evaluated to zero.",
                affected=f"Division expression on line {line}: `{snippet.strip()}`",
                how_to_fix="Check if the divisor is non-zero before dividing: `if divisor != 0: ...`",
                confidence="High",
                provider="local_heuristic",
            )

        # 7. KeyError
        if err_type == "KeyError":
            match = re.search(r"['\"]?([^'\"]+)['\"]?", msg)
            key = match.group(1) if match else "key"
            return ExplanationResult(
                what=f"KeyError: Dictionary key {key} not found.",
                where=where,
                why="You accessed a dictionary using a key that does not exist in the dictionary map.",
                cause=f"The key {key} is missing from the dictionary.",
                affected=f"Dictionary access on line {line}: `{snippet.strip()}`",
                how_to_fix=f"Use `dict.get({key}, default_value)` or verify that the key exists with `if {key} in dict:`.",
                confidence="High",
                provider="local_heuristic",
            )

        # 8. ValueError
        if err_type == "ValueError":
            return ExplanationResult(
                what="ValueError: Inappropriate argument value.",
                where=where,
                why="The function received an argument that has the right type but an inappropriate value.",
                cause=msg,
                affected=f"Call on line {line}: `{snippet.strip()}`",
                how_to_fix="Validate and sanitize user input before passing it into type-casting or parsing functions.",
                confidence="High",
                provider="local_heuristic",
            )

        # 9. AttributeError
        if err_type == "AttributeError":
            return ExplanationResult(
                what="AttributeError: Object does not have requested attribute or method.",
                where=where,
                why="Python tried to access a property or method that is not defined on that object type.",
                cause=msg,
                affected=f"Attribute access on line {line}: `{snippet.strip()}`",
                how_to_fix="Check the object's actual type and check for misspellings in the method/attribute name.",
                confidence="High",
                provider="local_heuristic",
            )

        # 10. ImportError / ModuleNotFoundError
        if err_type in ("ImportError", "ModuleNotFoundError"):
            return ExplanationResult(
                what=f"{err_type}: Cannot import required module or name.",
                where=where,
                why="Python could not find the specified package in the environment's search path.",
                cause=msg,
                affected=f"Import statement on line {line}: `{snippet.strip()}`",
                how_to_fix="Install the missing package via pip (e.g. `pip install <package>`) or check the module name.",
                confidence="High",
                provider="local_heuristic",
            )

        # Generic fallback
        return ExplanationResult(
            what=f"{err_type}: Program encountered an error.",
            where=where,
            why="An exception interrupted normal execution.",
            cause=msg,
            affected=f"Line {line}: `{snippet.strip()}`",
            how_to_fix="Examine the traceback details and verify the operation logic on this line.",
            confidence="Medium",
            provider="local_heuristic",
        )
