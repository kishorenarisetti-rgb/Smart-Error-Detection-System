"""SEDS Isolated Code Execution Architecture.

Provides safe, controlled Python code execution with:
- Scrubbed environment (never exposing API keys, secrets, or parent env).
- Disposable temporary directory isolation per run.
- Enforced execution timeout and output byte truncation.
- Docker sandbox integration adapter (when Docker daemon is present).
- Clear, honest security disclosures regarding execution constraints.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict

DEFAULT_TIMEOUT = float(os.getenv("EXECUTION_TIMEOUT_SECONDS", "5.0"))
MAX_OUTPUT_BYTES = int(os.getenv("MAX_OUTPUT_BYTES", "65536"))

# Blacklisted environment variable tokens that must never reach user code
SENSITIVE_PATTERNS = (
    "KEY", "SECRET", "TOKEN", "PASS", "CREDENTIAL", "API",
    "OPENAI", "GEMINI", "AUTH", "AWS", "SSH", "AGY", "SESSION"
)


@dataclass
class ExecutionResult:
    stdout: str
    stderr: str
    exit_code: int
    duration_ms: float
    timed_out: bool = False
    sandbox_mode: str = "restricted_local_process"
    security_notice: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class CodeRunner:
    """Controls isolated code execution with scrubbed environment and resource boundaries."""

    @classmethod
    def _is_docker_available(cls) -> bool:
        """Check if Docker CLI and daemon are operational."""
        try:
            res = subprocess.run(
                ["docker", "info"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=1.5,
            )
            return res.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False

    @classmethod
    def _get_scrubbed_env(cls) -> Dict[str, str]:
        """Produce a safe, stripped environment dictionary removing all secrets."""
        safe_keys = {
            "SYSTEMROOT", "WINDIR", "PATH", "TEMP", "TMP", "PATHEXT",
            "USERPROFILE", "LOCALAPPDATA", "LANG", "LC_ALL",
            "HOME", "USER", "LOGNAME", "HOSTNAME", "SHELL", "TERM",
            "TMPDIR", "LD_LIBRARY_PATH"
        }
        clean_env: Dict[str, str] = {}
        for k, v in os.environ.items():
            k_upper = k.upper()
            # Omit any sensitive environment variable
            if any(token in k_upper for token in SENSITIVE_PATTERNS):
                continue
            if k_upper in safe_keys:
                clean_env[k] = v

        clean_env["PYTHONUNBUFFERED"] = "1"
        clean_env["PYTHONDONTWRITEBYTECODE"] = "1"
        return clean_env

    @classmethod
    def run_code(
        cls,
        source_code: str,
        timeout: float = DEFAULT_TIMEOUT,
        prefer_docker: bool = False,
    ) -> ExecutionResult:
        """Execute Python code within isolated workspace with scrubbed environment."""
        start_time = time.perf_counter()

        # Check if Docker is requested and available
        if prefer_docker and cls._is_docker_available():
            return cls._run_in_docker(source_code, timeout, start_time)

        return cls._run_in_restricted_subprocess(source_code, timeout, start_time)

    @classmethod
    def _run_in_docker(
        cls, source_code: str, timeout: float, start_time: float
    ) -> ExecutionResult:
        """Run inside an ephemeral network-isolated container."""
        cmd = [
            "docker", "run", "--rm", "-i",
            "--network", "none",
            "--memory", "128m",
            "--cpus", "0.5",
            "--pids-limit", "32",
            "python:3.11-alpine",
            "python", "-u", "-"
        ]
        try:
            proc = subprocess.run(
                cmd,
                input=source_code,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
            )
            elapsed = (time.perf_counter() - start_time) * 1000
            stdout = proc.stdout[:MAX_OUTPUT_BYTES]
            stderr = proc.stderr[:MAX_OUTPUT_BYTES]
            return ExecutionResult(
                stdout=stdout,
                stderr=stderr,
                exit_code=proc.returncode,
                duration_ms=round(elapsed, 2),
                timed_out=False,
                sandbox_mode="docker_container",
                security_notice="Executed inside an isolated Docker container with network disabled and memory limits.",
            )
        except subprocess.TimeoutExpired:
            elapsed = (time.perf_counter() - start_time) * 1000
            return ExecutionResult(
                stdout="",
                stderr=f"Execution Timed Out: exceeded {timeout} seconds limit.",
                exit_code=-1,
                duration_ms=round(elapsed, 2),
                timed_out=True,
                sandbox_mode="docker_container",
                security_notice="Container execution halted by watchdog timeout.",
            )

    @classmethod
    def _run_in_restricted_subprocess(
        cls, source_code: str, timeout: float, start_time: float
    ) -> ExecutionResult:
        """Run with stripped environment in disposable isolated directory."""
        temp_dir = tempfile.mkdtemp(prefix="seds_sandbox_")
        script_path = Path(temp_dir) / "main.py"

        try:
            with open(script_path, "w", encoding="utf-8", newline="\n") as f:
                f.write(source_code)

            clean_env = cls._get_scrubbed_env()

            # Enforce OS-level resource limits on Linux (Render / Docker)
            preexec = None
            if os.name != "nt":
                def _limit_resources():
                    try:
                        import resource
                        # 256 MB virtual memory cap
                        mem_limit = int(os.getenv("MAX_MEMORY_BYTES", str(256 * 1024 * 1024)))
                        resource.setrlimit(resource.RLIMIT_AS, (mem_limit, mem_limit))
                        # CPU execution limit
                        cpu_limit = int(timeout) + 1
                        resource.setrlimit(resource.RLIMIT_CPU, (cpu_limit, cpu_limit))
                    except Exception:
                        pass
                preexec = _limit_resources

            # Execute with sys.executable in isolated directory
            proc = subprocess.run(
                [sys.executable, "-I", str(script_path)],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                cwd=temp_dir,
                env=clean_env,
                timeout=timeout,
                preexec_fn=preexec,
            )
            elapsed = (time.perf_counter() - start_time) * 1000

            stdout = proc.stdout[:MAX_OUTPUT_BYTES]
            stderr = proc.stderr[:MAX_OUTPUT_BYTES]

            return ExecutionResult(
                stdout=stdout,
                stderr=stderr,
                exit_code=proc.returncode,
                duration_ms=round(elapsed, 2),
                timed_out=False,
                sandbox_mode="restricted_local_process",
                security_notice=(
                    "Executed in isolated disposable directory with scrubbed environment "
                    "(application secrets and sensitive keys removed)."
                ),
            )
        except subprocess.TimeoutExpired:
            elapsed = (time.perf_counter() - start_time) * 1000
            return ExecutionResult(
                stdout="",
                stderr=f"Execution Timed Out: Program exceeded {timeout} seconds time limit.",
                exit_code=-1,
                duration_ms=round(elapsed, 2),
                timed_out=True,
                sandbox_mode="restricted_local_process",
                security_notice="Execution halted by supervisor timeout limit.",
            )
        except Exception as exc:
            elapsed = (time.perf_counter() - start_time) * 1000
            return ExecutionResult(
                stdout="",
                stderr=f"Execution Failed: {exc}",
                exit_code=-1,
                duration_ms=round(elapsed, 2),
                timed_out=False,
                sandbox_mode="restricted_local_process",
                security_notice=f"Runner encounter: {exc}",
            )
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)
