"""SEDS Flask Application Server.

REST API powering the Smart Error Detection System:
- Code analysis & static detection (/api/detect)
- Isolated execution & runtime traceback parsing (/api/run)
- 7-point AI / Local Error Explanation (/api/explain)
- Validated code repair & diff generation (/api/fix)
- Multi-file project scanning (/api/scan)
- Session history & analytics (/api/history)
- Service status (/api/status)
"""

from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

from backend.ai_service import AIService
from backend.auto_fixer import AutoFixer
from backend.code_runner import CodeRunner
from backend.database import Database
from backend.detector import DetectedError, ErrorDetector
from backend.error_explainer import ErrorExplainer
from backend.project_scanner import ProjectScanner

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

app = Flask(__name__, static_folder=str(FRONTEND_DIR))

# Secure CORS configuration
cors_origins_env = os.getenv("CORS_ORIGINS", "*").strip()
if cors_origins_env == "*":
    CORS(app, resources={r"/api/*": {"origins": "*"}, r"/healthz": {"origins": "*"}})
else:
    allowed_list = [origin.strip() for origin in cors_origins_env.split(",") if origin.strip()]
    CORS(app, resources={r"/api/*": {"origins": allowed_list}, r"/healthz": {"origins": allowed_list}})

# Initialize SQLite schema
Database.init_db()


@app.route("/healthz", methods=["GET"])
def health_check():
    """Lightweight health check endpoint for Render, Docker, and Kubernetes."""
    return jsonify({
        "status": "healthy",
        "service": "SEDS Production Backend",
        "version": "2.0.0"
    }), 200


@app.route("/")
def index():
    """Serve the single-page application."""
    return send_from_directory(str(FRONTEND_DIR), "index.html")


@app.route("/<path:path>")
def static_files(path):
    """Serve CSS, JS, and asset files."""
    return send_from_directory(str(FRONTEND_DIR), path)


@app.route("/api/status", methods=["GET"])
def get_status():
    """Return system readiness, AI configuration, and sandbox info."""
    return jsonify({
        "status": "online",
        "system": "Smart Error Detection System (SEDS)",
        "version": "2.0.0",
        "ai": AIService.get_status(),
        "sandbox": {
            "timeout_seconds": float(os.getenv("EXECUTION_TIMEOUT_SECONDS", "5.0")),
            "secrets_scrubbed": True,
            "docker_available": CodeRunner._is_docker_available(),
        },
    })


@app.route("/api/detect", methods=["POST"])
def detect_code_errors():
    """Perform static AST & token detection without running the code."""
    data = request.get_json(force=True, silent=True) or {}
    code = data.get("code", "")

    errors = ErrorDetector.detect_static(code)
    error_list = [e.to_dict() for e in errors]

    primary_error = None
    explanation = None
    fix = None

    if errors:
        primary_error = errors[0]
        consent = bool(data.get("user_consent", False))
        provider = data.get("preferred_provider", "auto")

        expl_res = ErrorExplainer.explain(primary_error, code, user_consent=consent, preferred_provider=provider)
        explanation = expl_res.to_dict()

        fix_res = AutoFixer.generate_fix(primary_error, code, user_consent=consent, preferred_provider=provider)
        fix = fix_res.to_dict()

    return jsonify({
        "errors": error_list,
        "count": len(error_list),
        "primary_error": primary_error.to_dict() if primary_error else None,
        "explanation": explanation,
        "fix": fix,
    })


@app.route("/api/run", methods=["POST"])
def run_and_diagnose():
    """Execute code in isolated runner, parse runtime errors, and generate AI explanation & fix."""
    data = request.get_json(force=True, silent=True) or {}
    code = data.get("code", "")
    timeout = float(data.get("timeout", os.getenv("EXECUTION_TIMEOUT_SECONDS", "5.0")))
    consent = bool(data.get("user_consent", False))
    provider = data.get("preferred_provider", "auto")

    # 1. First run static analysis to catch pre-execution syntax/token errors
    static_errors = ErrorDetector.detect_static(code)
    syntax_blocking = any(e.severity == "error" for e in static_errors)

    if syntax_blocking:
        primary_err = static_errors[0]
        expl = ErrorExplainer.explain(primary_err, code, user_consent=consent, preferred_provider=provider)
        fix = AutoFixer.generate_fix(primary_err, code, user_consent=consent, preferred_provider=provider)

        session_id = Database.save_session(
            title="Static Error Detected",
            source_code=code,
            error_type=primary_err.error_type,
            error_line=primary_err.line,
            error_message=primary_err.message,
            applied_fix=fix.fixed_code if fix.is_valid else None,
            execution_output=f"Static Syntax Check Failed on Line {primary_err.line}",
        )
        Database.log_error(
            error_type=primary_err.error_type,
            error_message=primary_err.message,
            line=primary_err.line,
            column=primary_err.column,
            source_snippet=primary_err.source_snippet,
            session_id=session_id,
            fixed_successfully=fix.is_valid,
            provider_used=expl.provider,
        )

        return jsonify({
            "stdout": "",
            "stderr": f"Static Error Detected: {primary_err.error_type} on Line {primary_err.line}: {primary_err.message}",
            "exit_code": 1,
            "duration_ms": 0.0,
            "timed_out": False,
            "errors": [e.to_dict() for e in static_errors],
            "primary_error": primary_err.to_dict(),
            "explanation": expl.to_dict(),
            "fix": fix.to_dict(),
            "security_notice": "Static syntax check caught issue prior to execution.",
            "session_id": session_id,
        })

    # 2. Run code in isolated environment
    run_result = CodeRunner.run_code(code, timeout=timeout)

    detected_errors = []
    primary_err = None
    explanation = None
    fix = None

    if run_result.exit_code != 0:
        detected_errors = ErrorDetector.detect_all(code, runtime_stderr=run_result.stderr)
        if detected_errors:
            primary_err = detected_errors[0]
            expl = ErrorExplainer.explain(primary_err, code, user_consent=consent, preferred_provider=provider)
            explanation = expl.to_dict()
            fix_obj = AutoFixer.generate_fix(primary_err, code, user_consent=consent, preferred_provider=provider)
            fix = fix_obj.to_dict()

    # Log to SQLite
    session_id = Database.save_session(
        title="Code Execution Run",
        source_code=code,
        error_type=primary_err.error_type if primary_err else None,
        error_line=primary_err.line if primary_err else None,
        error_message=primary_err.message if primary_err else None,
        applied_fix=fix.get("fixed_code") if fix and fix.get("is_valid") else None,
        execution_output=run_result.stdout or run_result.stderr,
    )

    if primary_err:
        Database.log_error(
            error_type=primary_err.error_type,
            error_message=primary_err.message,
            line=primary_err.line,
            column=primary_err.column,
            source_snippet=primary_err.source_snippet,
            session_id=session_id,
            fixed_successfully=fix.get("is_valid", False) if fix else False,
            provider_used=explanation.get("provider", "local") if explanation else "local",
        )

    return jsonify({
        "stdout": run_result.stdout,
        "stderr": run_result.stderr,
        "exit_code": run_result.exit_code,
        "duration_ms": run_result.duration_ms,
        "timed_out": run_result.timed_out,
        "errors": [e.to_dict() for e in detected_errors],
        "primary_error": primary_err.to_dict() if primary_err else None,
        "explanation": explanation,
        "fix": fix,
        "security_notice": run_result.security_notice,
        "session_id": session_id,
    })


@app.route("/api/fix", methods=["POST"])
def generate_fix_endpoint():
    """Generate and validate a fix for an existing error."""
    data = request.get_json(force=True, silent=True) or {}
    code = data.get("code", "")
    err_dict = data.get("error", {})
    consent = bool(data.get("user_consent", False))
    provider = data.get("preferred_provider", "auto")

    if not err_dict:
        # Detect static errors if not provided
        errs = ErrorDetector.detect_static(code)
        if not errs:
            return jsonify({"error": "No error provided or detected to fix."}), 400
        error_obj = errs[0]
    else:
        error_obj = DetectedError(
            error_type=err_dict.get("error_type", "SyntaxError"),
            message=err_dict.get("message", ""),
            line=err_dict.get("line", 1),
            column=err_dict.get("column", 1),
            source_snippet=err_dict.get("source_snippet", ""),
            category=err_dict.get("category", "syntax"),
            details=err_dict.get("details", {}),
        )

    fix = AutoFixer.generate_fix(error_obj, code, user_consent=consent, preferred_provider=provider)
    return jsonify({"fix": fix.to_dict()})


@app.route("/api/scan", methods=["POST"])
def scan_project_endpoint():
    """Scan a target directory for Python errors."""
    data = request.get_json(force=True, silent=True) or {}
    folder_path = data.get("folder_path", "").strip()

    if not folder_path:
        return jsonify({"error": "folder_path is required."}), 400

    try:
        report = ProjectScanner.scan_directory(folder_path)
        report_data = report.to_dict()

        # Save to database
        scan_id = Database.save_scan(
            folder_path=report.folder_path,
            total_files=report.total_files,
            passed_files=report.passed_files,
            failed_files=report.failed_files,
            report_data=report_data,
        )
        report_data["scan_id"] = scan_id
        return jsonify({"report": report_data})
    except ValueError as val_err:
        return jsonify({"error": str(val_err)}), 404
    except Exception as exc:
        return jsonify({"error": f"Scan failed: {exc}"}), 500


@app.route("/api/history", methods=["GET"])
def get_history():
    """Retrieve recent sessions, scans, and analytics summary."""
    sessions = Database.get_recent_sessions(limit=25)
    scans = Database.get_scan_history(limit=10)
    analytics = Database.get_analytics()
    return jsonify({
        "sessions": sessions,
        "scans": scans,
        "analytics": analytics,
    })


if __name__ == "__main__":
    port = int(os.getenv("PORT", os.getenv("SEDS_PORT", "5000")))
    host = os.getenv("SEDS_HOST", "0.0.0.0")
    debug = os.getenv("SEDS_DEBUG", "False").lower() == "true"
    print(f"[*] Starting SEDS Server on http://{host}:{port} (debug={debug})")
    app.run(host=host, port=port, debug=debug)
