"""SEDS Backend Package - Smart Error Detection System."""
