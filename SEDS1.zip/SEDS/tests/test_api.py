"""Integration tests for SEDS Flask REST API."""

import json

from backend.app import app


def test_api_status():
    client = app.test_client()
    resp = client.get("/api/status")
    assert resp.status_code == 200
    data = json.loads(resp.data)
    assert data["status"] == "online"
    assert "Smart Error Detection System" in data["system"]


def test_api_healthz():
    client = app.test_client()
    resp = client.get("/healthz")
    assert resp.status_code == 200
    data = json.loads(resp.data)
    assert data["status"] == "healthy"


def test_api_detect_missing_bracket():
    client = app.test_client()
    payload = {"code": "numbers = [10, 20, 30\nprint(numbers)"}
    resp = client.post("/api/detect", json=payload)
    assert resp.status_code == 200
    data = json.loads(resp.data)
    assert data["count"] >= 1
    assert data["primary_error"]["error_type"] == "SyntaxError"
    assert data["explanation"] is not None
    assert data["fix"]["is_valid"] is True


def test_api_detect_unterminated_string():
    client = app.test_client()
    payload = {"code": 'print("hello)'}
    resp = client.post("/api/detect", json=payload)
    assert resp.status_code == 200
    data = json.loads(resp.data)
    assert data["count"] >= 1
    assert data["primary_error"]["error_type"] == "SyntaxError"
    assert data["fix"]["is_valid"] is True
    assert data["fix"]["fixed_code"] == 'print("hello")'
    assert "Unterminated string literal" in data["explanation"]["what"]


def test_api_run_success():
    client = app.test_client()
    payload = {"code": "x = 40 + 2\nprint(f'Answer: {x}')"}
    resp = client.post("/api/run", json=payload)
    assert resp.status_code == 200
    data = json.loads(resp.data)
    assert data["exit_code"] == 0
    assert "Answer: 42" in data["stdout"]


def test_api_run_runtime_error():
    client = app.test_client()
    payload = {"code": "colors = ['red', 'blue']\nprint(colors[5])"}
    resp = client.post("/api/run", json=payload)
    assert resp.status_code == 200
    data = json.loads(resp.data)
    assert data["exit_code"] != 0
    assert data["primary_error"]["error_type"] == "IndexError"
    assert data["explanation"]["what"].startswith("IndexError")


def test_api_history():
    client = app.test_client()
    resp = client.get("/api/history")
    assert resp.status_code == 200
    data = json.loads(resp.data)
    assert "sessions" in data
    assert "analytics" in data


def test_frontend_static_serving():
    client = app.test_client()
    resp_index = client.get("/")
    assert resp_index.status_code == 200
    assert b"Smart Error Detection System" in resp_index.data

    resp_css = client.get("/style.css")
    assert resp_css.status_code == 200
    assert b"vscode-dark" in resp_css.data or b"--bg-dark" in resp_css.data

    resp_js = client.get("/script.js")
    assert resp_js.status_code == 200
    assert b"SEDS" in resp_js.data

