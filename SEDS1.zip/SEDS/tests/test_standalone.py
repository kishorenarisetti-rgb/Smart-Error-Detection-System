"""Tests verifying the standalone all-in-one SEDS.py script."""

import json

import SEDS


def test_standalone_static_detection():
    code = "numbers = [10, 20, 30\nprint(numbers)"
    errors = SEDS.ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    assert errors[0].error_type == "SyntaxError"
    assert errors[0].line == 1


def test_standalone_explanation_and_fix():
    code = "if x > 10\n    print(x)"
    errors = SEDS.ErrorDetector.detect_static(code)
    colon_err = [e for e in errors if "colon" in e.message.lower()][0]
    expl = SEDS.ErrorExplainer.explain(colon_err, code)
    assert "Missing colon" in expl.what
    fix = SEDS.AutoFixer.generate_fix(colon_err, code)
    assert fix.is_valid is True
    assert fix.fixed_code.startswith("if x > 10:")


def test_standalone_flask_app():
    client = SEDS.app.test_client()
    resp_index = client.get("/")
    assert resp_index.status_code == 200
    assert b"Smart Error Detection System" in resp_index.data

    resp_run = client.post("/api/run", json={"code": "print(10 * 5)"})
    assert resp_run.status_code == 200
    data = json.loads(resp_run.data)
    assert data["exit_code"] == 0
    assert "50" in data["stdout"]
