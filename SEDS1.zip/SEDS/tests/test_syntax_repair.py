"""Verification tests for SyntaxError detection and automatic code repair."""

from backend.auto_fixer import AutoFixer
from backend.detector import ErrorDetector


def test_unterminated_string_literal_in_call():
    code = 'print("hello)'
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    err = errors[0]
    assert err.error_type == "SyntaxError"

    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert fix_res.fixed_code == 'print("hello")'
    assert "-" in fix_res.diff and "+" in fix_res.diff


def test_unterminated_single_quote_assignment():
    code = "name = 'Kishore\nprint(name)"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    err = errors[0]
    assert err.error_type == "SyntaxError"

    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert fix_res.fixed_code == "name = 'Kishore'\nprint(name)"


def test_missing_colon_if_statement():
    code = 'if True\n    print("Hello")'
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    err = errors[0]
    assert err.error_type == "SyntaxError"

    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert fix_res.fixed_code == 'if True:\n    print("Hello")'


def test_unclosed_string_and_parenthesis():
    code = 'print("Hello"'
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    err = errors[0]
    assert err.error_type == "SyntaxError"

    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert fix_res.fixed_code == 'print("Hello")'


def test_valid_code_no_error():
    code = "x = 10\nprint(x)"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) == 0
