"""Tests for the SEDS Error Detection Engine."""

from backend.detector import ErrorDetector


def test_missing_bracket_detection():
    code = "numbers = [10, 20, 30\nprint(numbers)"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    err = errors[0]
    assert err.error_type == "SyntaxError"
    assert "square bracket ']'" in err.message or "Missing closing" in err.message
    assert err.line == 1


def test_missing_colon_detection():
    code = "if x > 5\n    print('hello')"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    # Check that colon error was detected
    colon_errs = [e for e in errors if "colon" in e.message.lower()]
    assert len(colon_errs) >= 1
    assert colon_errs[0].line == 1


def test_undefined_variable_detection():
    code = "x = 10\nprint(y)"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    err = [e for e in errors if e.error_type == "NameError"][0]
    assert "undefined variable" in err.message.lower() or "used before definition" in err.message.lower()
    assert err.line == 2


def test_type_mismatch_static():
    code = 'result = "hello" + 5'
    errors = ErrorDetector.detect_static(code)
    assert any(e.error_type == "TypeError" for e in errors)


def test_zero_division_static():
    code = "res = 100 / 0"
    errors = ErrorDetector.detect_static(code)
    assert any(e.error_type == "ZeroDivisionError" for e in errors)


def test_tab_error_detection():
    code = "def foo():\n\t    x = 1\n    return x"
    errors = ErrorDetector.detect_static(code)
    assert any(e.error_type == "TabError" for e in errors)


def test_unclosed_string_quote():
    code = 'msg = "hello world\nprint(msg)'
    errors = ErrorDetector.detect_static(code)
    assert any("quotation mark" in e.message.lower() or "string" in e.message.lower() for e in errors)


def test_function_too_many_arguments():
    code = "def add(a, b):\n    return a + b\nres = add(1, 2, 3)"
    errors = ErrorDetector.detect_static(code)
    type_errs = [e for e in errors if e.error_type == "TypeError"]
    assert len(type_errs) >= 1
    assert "expects 2" in type_errs[0].message


def test_runtime_traceback_index_error():
    tb = """Traceback (most recent call last):
  File "c:\\temp\\script.py", line 4, in <module>
    print(items[10])
IndexError: list index out of range"""
    source = "items = [1, 2]\n# comment\n# comment\nprint(items[10])"
    err = ErrorDetector.parse_runtime_traceback(tb, source)
    assert err is not None
    assert err.error_type == "IndexError"
    assert err.line == 4
    assert err.message == "list index out of range"
    assert "items[10]" in err.source_snippet


def test_runtime_traceback_key_error():
    tb = """Traceback (most recent call last):
  File "test.py", line 3, in <module>
    val = data["missing_key"]
KeyError: 'missing_key'"""
    err = ErrorDetector.parse_runtime_traceback(tb, 'data = {}\n#\nval = data["missing_key"]')
    assert err is not None
    assert err.error_type == "KeyError"
    assert err.line == 3
    assert err.message == "'missing_key'"


def test_runtime_traceback_attribute_error():
    tb = """Traceback (most recent call last):
  File "test.py", line 2, in <module>
    "hello".non_existent()
AttributeError: 'str' object has no attribute 'non_existent'"""
    err = ErrorDetector.parse_runtime_traceback(tb, 'x = 1\n"hello".non_existent()')
    assert err is not None
    assert err.error_type == "AttributeError"
    assert err.line == 2


def test_runtime_traceback_import_error():
    tb = """Traceback (most recent call last):
  File "test.py", line 1, in <module>
    import non_existent_super_module_xyz
ModuleNotFoundError: No module named 'non_existent_super_module_xyz'"""
    err = ErrorDetector.parse_runtime_traceback(tb, "import non_existent_super_module_xyz")
    assert err is not None
    assert err.error_type == "ModuleNotFoundError"
    assert err.line == 1
