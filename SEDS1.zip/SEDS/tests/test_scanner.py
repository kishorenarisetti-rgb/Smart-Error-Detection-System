"""Unit tests for the SEDS Project Scanner."""

import tempfile
from pathlib import Path

from backend.project_scanner import ProjectScanner


def test_project_scanner():
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)

        # File 1: clean file
        f1 = temp_path / "valid.py"
        f1.write_text("def hello():\n    return 'world'\n", encoding="utf-8")

        # File 2: file with missing colon
        f2 = temp_path / "syntax_err.py"
        f2.write_text("if x > 10\n    print(x)\n", encoding="utf-8")

        # File 3: file with missing bracket
        f3 = temp_path / "bracket_err.py"
        f3.write_text("data = [1, 2, 3\n", encoding="utf-8")

        # Subdirectory with excluded pattern
        venv_dir = temp_path / ".venv"
        venv_dir.mkdir()
        (venv_dir / "ignored.py").write_text("bad syntax ((((", encoding="utf-8")

        report = ProjectScanner.scan_directory(str(temp_path))
        data = report.to_dict()

        assert data["total_files"] == 3  # ignored.py in .venv must be skipped
        assert data["passed_files"] == 1
        assert data["failed_files"] == 2
        assert data["duration_ms"] > 0
        assert len(data["files"]) == 3
