"""Comprehensive tests for SEDS multi-error auto-repair engine."""

from backend.auto_fixer import AutoFixer
from backend.detector import ErrorDetector


def test_fix_missing_import():
    code = "result = math.sqrt(16)\nprint(result)"
    tb = """Traceback (most recent call last):
  File "test.py", line 1, in <module>
    result = math.sqrt(16)
NameError: name 'math' is not defined"""
    err = ErrorDetector.parse_runtime_traceback(tb, code)
    assert err is not None
    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert "import math" in fix_res.fixed_code
    assert "math.sqrt(16)" in fix_res.fixed_code


def test_fix_assignment_in_condition():
    code = "x = 10\nif x = 10:\n    print('Equal')"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    fix_res = AutoFixer.generate_fix(errors[0], code)
    assert fix_res.is_valid is True
    assert "if x == 10:" in fix_res.fixed_code


def test_fix_c_style_logical_operators():
    code = "x = 5\ny = 10\nif x > 0 && y > 0:\n    print('Positive')"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    fix_res = AutoFixer.generate_fix(errors[0], code)
    assert fix_res.is_valid is True
    assert "if x > 0 and y > 0:" in fix_res.fixed_code


def test_fix_print_statement_missing_parens():
    code = 'print "Hello World"'
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    fix_res = AutoFixer.generate_fix(errors[0], code)
    assert fix_res.is_valid is True
    assert fix_res.fixed_code == 'print("Hello World")'


def test_fix_type_error_str_int_concat():
    code = 'age = 25\nmsg = "Age: " + age\nprint(msg)'
    tb = """Traceback (most recent call last):
  File "test.py", line 2, in <module>
    msg = "Age: " + age
TypeError: can only concatenate str (not "int") to str"""
    err = ErrorDetector.parse_runtime_traceback(tb, code)
    assert err is not None
    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert "str(age)" in fix_res.fixed_code


def test_fix_key_error_dict():
    code = 'data = {"name": "Alice"}\nprint(data["age"])'
    tb = """Traceback (most recent call last):
  File "test.py", line 2, in <module>
    print(data["age"])
KeyError: 'age'"""
    err = ErrorDetector.parse_runtime_traceback(tb, code)
    assert err is not None
    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert 'data.get("age")' in fix_res.fixed_code or "data.get('age')" in fix_res.fixed_code


def test_fix_index_error_list():
    code = "items = [1, 2, 3]\nprint(items[10])"
    tb = """Traceback (most recent call last):
  File "test.py", line 2, in <module>
    print(items[10])
IndexError: list index out of range"""
    err = ErrorDetector.parse_runtime_traceback(tb, code)
    assert err is not None
    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert "len(items)" in fix_res.fixed_code or "if" in fix_res.fixed_code


def test_fix_attribute_error_method_typo():
    code = "fruits = ['apple']\nfruits.appendd('banana')\nprint(fruits)"
    tb = """Traceback (most recent call last):
  File "test.py", line 2, in <module>
    fruits.appendd('banana')
AttributeError: 'list' object has no attribute 'appendd'"""
    err = ErrorDetector.parse_runtime_traceback(tb, code)
    assert err is not None
    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert "fruits.append('banana')" in fix_res.fixed_code
