"""Unit tests for SEDS CodeRunner execution sandbox."""

import os

from backend.code_runner import CodeRunner


def test_successful_code_execution():
    res = CodeRunner.run_code('print("Hello from SEDS runner!")', timeout=3.0)
    assert res.exit_code == 0
    assert "Hello from SEDS runner!" in res.stdout
    assert not res.timed_out
    assert res.duration_ms > 0


def test_runtime_error_execution():
    res = CodeRunner.run_code("x = 10 / 0", timeout=3.0)
    assert res.exit_code != 0
    assert "ZeroDivisionError" in res.stderr


def test_timeout_protection():
    code = "import time\ntime.sleep(5)\nprint('done')"
    res = CodeRunner.run_code(code, timeout=1.0)
    assert res.timed_out is True
    assert "timed out" in res.stderr.lower()


def test_scrubbed_environment():
    os.environ["OPENAI_API_KEY"] = "sk-secret-test-key-12345"
    code = "import os\nprint('SECRET_PRESENT:', 'OPENAI_API_KEY' in os.environ)"
    res = CodeRunner.run_code(code, timeout=3.0)
    assert "SECRET_PRESENT: False" in res.stdout
