"""Unit tests for SEDS Error Explainer and Auto Fixer."""

from backend.auto_fixer import AutoFixer
from backend.detector import ErrorDetector
from backend.error_explainer import ErrorExplainer


def test_fix_missing_bracket():
    code = "numbers = [10, 20, 30\nprint(numbers)"
    errors = ErrorDetector.detect_static(code)
    assert len(errors) >= 1
    fix_res = AutoFixer.generate_fix(errors[0], code)
    assert fix_res.is_valid is True
    assert fix_res.fixed_code is not None
    assert "]" in fix_res.fixed_code
    assert "Original Code" in fix_res.diff


def test_fix_missing_colon():
    code = "if x > 5\n    print(x)"
    errors = ErrorDetector.detect_static(code)
    colon_errs = [e for e in errors if "colon" in e.message.lower()]
    assert len(colon_errs) >= 1
    fix_res = AutoFixer.generate_fix(colon_errs[0], code)
    assert fix_res.is_valid is True
    assert fix_res.fixed_code.startswith("if x > 5:")


def test_fix_misspelled_name():
    code = "numbers = [1, 2, 3]\nprnt(numbers)"
    errors = ErrorDetector.detect_static(code)
    name_errs = [e for e in errors if e.error_type == "NameError"]
    assert len(name_errs) >= 1
    fix_res = AutoFixer.generate_fix(name_errs[0], code)
    assert fix_res.is_valid is True
    assert "print(numbers)" in fix_res.fixed_code


def test_fix_zero_division():
    code = "x = 10\ny = 0\nres = x / y"
    tb = """Traceback (most recent call last):
  File "test.py", line 3, in <module>
    res = x / y
ZeroDivisionError: division by zero"""
    err = ErrorDetector.parse_runtime_traceback(tb, code)
    assert err is not None
    fix_res = AutoFixer.generate_fix(err, code)
    assert fix_res.is_valid is True
    assert "if y != 0" in fix_res.fixed_code


def test_error_explainer_structure():
    code = "if a > 10\n    print(a)"
    errors = ErrorDetector.detect_static(code)
    expl = ErrorExplainer.explain(errors[0], code)
    data = expl.to_dict()
    for key in ("what", "where", "why", "cause", "affected", "how_to_fix", "confidence", "provider"):
        assert key in data
        assert isinstance(data[key], str)
        assert len(data[key]) > 0
