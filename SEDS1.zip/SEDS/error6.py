#!/usr/bin/env python3
"""
Smart Error Detection System
A small Python IDE with rule-based AI error explanation and auto-fix.
"""

import os
import re
import subprocess
import sys
import tempfile
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import ast
import tokenize
from pathlib import Path


# ---------------- CONFIG ----------------

TITLE = "Smart Error Detection System"
BG = "#1e1e1e"
FG = "#d4d4d4"
ACCENT = "#3b82f6"
SUCCESS = "#22c55e"
FONT = ("Consolas", 12)


def auto_fix(code: str, error_type: str, error_msg: str) -> str:
    """Return a best-effort fixed version of the code, or a message."""

    if error_type == "SyntaxError":
        # Unterminated string literal (e.g., print("hello)
        if re.search(r"EOL while scanning string literal|unterminated string", error_msg, re.I):
            fixed = code.rstrip()
            if fixed.count('"') % 2 != 0:
                fixed += '"'
            elif fixed.count("'") % 2 != 0:
                fixed += "'"
            else:
                fixed += '"'
            # Also close open parentheses if any
            open_p = fixed.count("(")
            close_p = fixed.count(")")
            if open_p > close_p:
                fixed += ")" * (open_p - close_p)
            return fixed + "\n"

        # Unclosed brackets or parentheses
        if re.search(r"was never closed|unexpected EOF|'\(' was never closed|closing parenthesis", error_msg, re.I):
            fixed = code.rstrip()
            open_p = fixed.count("(")
            close_p = fixed.count(")")
            if open_p > close_p:
                fixed += ")" * (open_p - close_p)
            open_b = fixed.count("[")
            close_b = fixed.count("]")
            if open_b > close_b:
                fixed += "]" * (open_b - close_b)
            open_c = fixed.count("{")
            close_c = fixed.count("}")
            if open_c > close_c:
                fixed += "}" * (open_c - close_c)
            return fixed + "\n"

        # Missing colon (e.g., if/for/while/def/class)
        if re.search(r"expected ':'", error_msg, re.I):
            lines = code.splitlines()
            if lines:
                lines[0] = lines[0].rstrip() + ":"
                return "\n".join(lines) + "\n"

    if error_type == "ZeroDivisionError":
        return re.sub(r"\/\s*0(?!\d)", "/ 1", code)

    if error_type == "NameError":
        m = re.search(r"name '([^']+)' is not defined|'([^']+)'", error_msg)
        if m:
            var_name = m.group(1) or m.group(2)
            return f"{var_name} = 0\n" + code

    if error_type in ("IndentationError", "TabError"):
        return code.replace("\t", "    ")

    if error_type == "IndexError":
        return "# Fix: list index out of range\n" + code

    if error_type == "TypeError":
        return "# Fix: data type mismatch\n" + code

    if error_type == "KeyError":
        return "# Fix: missing dictionary key\n" + code

    return "No automatic fix available."


def explain_error(error_type: str, error_msg: str, line: int | None) -> str:
    """Return a human-readable explanation of the error."""

    details = {
        "SyntaxError": "Python could not understand the code. Usually a missing bracket, quote, or colon.",
        "IndentationError": "The indentation (spaces at the start of a line) is wrong.",
        "TabError": "You mixed tabs and spaces for indentation.",
        "NameError": "You tried to use a variable or function that has not been defined yet.",
        "TypeError": "You used the wrong data type for an operation, e.g. adding a number to text.",
        "ValueError": "The value is the right type but not suitable for this operation.",
        "IndexError": "You asked for a position in a list that does not exist.",
        "KeyError": "You asked for a dictionary key that does not exist.",
        "ZeroDivisionError": "You tried to divide a number by zero, which is not allowed.",
        "AttributeError": "You tried to access an attribute or method that does not exist on this object.",
    }

    explanation = details.get(error_type, "An error occurred while running the code.")
    location = f"Line {line}" if line else "Unknown line"
    return f"Error Type: {error_type}\n{location}\n\nExplanation:\n{explanation}\n\nAI Suggestion:\nCheck the highlighted line and click Apply Fix if a fix is available."


def parse_error(stderr: str) -> tuple[str, str, int | None]:
    """Parse the last exception type, message, and line number from stderr."""

    lines = stderr.strip().split("\n")
    last = lines[-1] if lines else ""

    m = re.match(r"^([A-Za-z_][\w.]*):\s*(.*)$", last)
    error_type = m.group(1) if m else "Error"
    error_msg = m.group(2) if m else last

    line = None
    for line_text in lines:
        lm = re.search(r'File "[^"]+", line (\d+)', line_text) or re.search(r"line (\d+)", line_text)
        if lm:
            line = int(lm.group(1))

    return error_type, error_msg, line


class SmartIDE:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(TITLE)
        self.root.configure(bg=BG)
        self.root.geometry("1200x700")

        self.current_file: str | None = None

        self.build_ui()
        self.set_default_code()

    def build_ui(self) -> None:
        # Top bar
        top = tk.Frame(self.root, bg=BG)
        top.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(top, text=TITLE, fg="white", bg=BG, font=("Arial", 14, "bold")).pack(side=tk.LEFT)

        self.status = tk.Label(top, text="Ready", fg=FG, bg=BG, font=("Arial", 10))
        self.status.pack(side=tk.RIGHT)

        # Main panes
        main = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, bg=BG)
        main.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left: editor
        left = tk.Frame(main, bg=BG)
        main.add(left, width=600)

        tk.Label(left, text="Code Editor", fg="white", bg=BG, font=("Arial", 12, "bold")).pack(anchor=tk.W, padx=5, pady=5)

        self.editor = scrolledtext.ScrolledText(left, wrap=tk.NONE, bg="#0d0d0d", fg=FG, insertbackground="white",
                                                font=FONT, undo=True)
        self.editor.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.editor.bind("<KeyRelease>", lambda e: self.highlight_error_line())

        editor_btns = tk.Frame(left, bg=BG)
        editor_btns.pack(fill=tk.X, padx=5, pady=5)

        tk.Button(editor_btns, text="Run", command=self.run_code, bg=ACCENT, fg="white", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=2)
        tk.Button(editor_btns, text="Open", command=self.open_file, bg="#333", fg="white").pack(side=tk.LEFT, padx=2)
        tk.Button(editor_btns, text="Save", command=self.save_file, bg="#333", fg="white").pack(side=tk.LEFT, padx=2)
        tk.Button(editor_btns, text="Clear", command=self.clear_editor, bg="#333", fg="white").pack(side=tk.LEFT, padx=2)
        tk.Button(
            editor_btns,
            text="Scan Project",
            command=self.scan_project,
            bg="#7c3aed",
            fg="white"
        ).pack(side=tk.LEFT, padx=2)

        # Right: explanation, fix, terminal
        right = tk.Frame(main, bg=BG)
        main.add(right, width=600)

        tk.Label(right, text="AI Error Explanation", fg="white", bg=BG, font=("Arial", 12, "bold")).pack(anchor=tk.W, padx=5, pady=5)
        self.explain_box = scrolledtext.ScrolledText(right, wrap=tk.WORD, bg="#252526", fg="#9cdcfe", font=FONT, height=8)
        self.explain_box.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(right, text="AI Auto Fix", fg="white", bg=BG, font=("Arial", 12, "bold")).pack(anchor=tk.W, padx=5, pady=5)
        self.fix_box = scrolledtext.ScrolledText(right, wrap=tk.NONE, bg="#252526", fg="#ce9178", font=FONT, height=8)
        self.fix_box.pack(fill=tk.X, padx=5, pady=5)

        tk.Button(right, text="Apply Fix", command=self.apply_fix, bg=SUCCESS, fg="white", font=("Arial", 10, "bold")).pack(pady=5)

        tk.Label(right, text="Terminal Output", fg="white", bg=BG, font=("Arial", 12, "bold")).pack(anchor=tk.W, padx=5, pady=5)
        self.terminal = scrolledtext.ScrolledText(right, wrap=tk.WORD, bg="black", fg="#00ff00", font=FONT)
        self.terminal.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def set_default_code(self) -> None:
        self.editor.delete("1.0", tk.END)
        self.editor.insert("1.0", 'print("Hello"')

    def clear_editor(self) -> None:
        self.editor.delete("1.0", tk.END)
        self.current_file = None
        self.root.title(TITLE)

    def highlight_error_line(self, line: int | None = None) -> None:
        self.editor.tag_remove("error_line", "1.0", tk.END)
        if line is None:
            return
        start = f"{line}.0"
        end = f"{line + 1}.0"
        self.editor.tag_add("error_line", start, end)
        self.editor.tag_config("error_line", background="#3f1f1f")

    def run_code(self) -> None:
        code = self.editor.get("1.0", tk.END)
        self.explain_box.delete("1.0", tk.END)
        self.fix_box.delete("1.0", tk.END)
        self.terminal.delete("1.0", tk.END)
        self.highlight_error_line(None)
        self.status.config(text="Running…")
        self.root.update_idletasks()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
            f.write(code)
            temp_path = f.name

        try:
            result = subprocess.run(
                [sys.executable, temp_path],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=5,
            )
        except subprocess.TimeoutExpired:
            self.terminal.insert(tk.END, "Error: Program timed out (more than 5 seconds).")
            self.status.config(text="Timed out")
            return
        except Exception as e:
            self.terminal.insert(tk.END, f"Runner error: {e}")
            self.status.config(text="Error")
            return
        finally:
            try:
                os.remove(temp_path)
            except OSError:
                pass

        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr
        self.terminal.insert(tk.END, output.strip() or "Program executed successfully.")

        if result.returncode != 0:
            error_type, error_msg, line = parse_error(result.stderr)
            self.explain_box.insert(tk.END, explain_error(error_type, error_msg, line))
            self.highlight_error_line(line)

            fix = auto_fix(code, error_type, error_msg)
            self.fix_box.insert(tk.END, fix)
            self.status.config(text=f"Error: {error_type}")
        else:
            self.status.config(text="Success")

    def apply_fix(self) -> None:
        fix = self.fix_box.get("1.0", tk.END).strip()
        if fix and fix != "No automatic fix available.":
            self.editor.delete("1.0", tk.END)
            self.editor.insert("1.0", fix)
            self.fix_box.delete("1.0", tk.END)
            self.explain_box.delete("1.0", tk.END)
            self.highlight_error_line(None)
            self.status.config(text="Fix applied")

    def open_file(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("Python files", "*.py"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                self.editor.delete("1.0", tk.END)
                self.editor.insert("1.0", f.read())
            self.current_file = path
            self.root.title(f"{TITLE} - {os.path.basename(path)}")
            self.status.config(text="File opened")
        except Exception as e:
            messagebox.showerror("Open Error", str(e))

    def save_file(self) -> None:
        if self.current_file:
            path = self.current_file
        else:
            path = filedialog.asksaveasfilename(defaultextension=".py", filetypes=[("Python files", "*.py")])
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.editor.get("1.0", tk.END))
            self.current_file = path
            self.root.title(f"{TITLE} - {os.path.basename(path)}")
            self.status.config(text="File saved")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def scan_project(self) -> None:
        folder = filedialog.askdirectory(title="Select Python Project Folder")
        if not folder:
            return

        excluded = {
            ".git", ".venv", "venv",
            "__pycache__", "node_modules"
        }

        self.terminal.delete("1.0", tk.END)
        self.explain_box.delete("1.0", tk.END)
        self.fix_box.delete("1.0", tk.END)
        self.highlight_error_line(None)
        self.status.config(text="Scanning project...")
        self.root.update_idletasks()

        results = []

        for root, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if d not in excluded]

            for filename in files:
                if not filename.endswith(".py"):
                    continue

                path = os.path.join(root, filename)

                try:
                    with tokenize.open(path) as f:
                        source = f.read()

                    ast.parse(source, filename=path)
                    results.append((path, "PASS", None))

                except SyntaxError as error:
                    results.append((
                        path,
                        "ERROR",
                        f"Line {error.lineno}: {error.msg}"
                    ))

                except (OSError, UnicodeError) as error:
                    results.append((
                        path,
                        "READ ERROR",
                        str(error)
                    ))

        if not results:
            self.terminal.insert(tk.END, "No Python files found in selected folder.\n")
            self.status.config(text="Scan completed: 0 files")
            return

        for path, status, error in results:
            self.terminal.insert(tk.END, f"\n[{status}] {path}\n")
            if error:
                self.terminal.insert(tk.END, f"    {error}\n")

        total = len(results)
        errors = sum(1 for _, status, _ in results if status == "ERROR")
        read_errors = sum(1 for _, status, _ in results if status == "READ ERROR")

        self.terminal.insert(
            tk.END,
            f"\n========== SEDS REPORT ==========\n"
            f"Total Python files: {total}\n"
            f"Successful files: {total - errors - read_errors}\n"
            f"Files with syntax errors: {errors}\n"
        )
        if read_errors:
            self.terminal.insert(tk.END, f"Files with read errors: {read_errors}\n")

        self.status.config(text=f"Scan completed: {errors} errors")
        if errors > 0:
            self.explain_box.insert(
                tk.END,
                f"Scan detected {errors} file(s) with syntax errors.\n"
                "Review the details in the Terminal Output."
            )
        else:
            self.explain_box.insert(tk.END, "Project scan passed: No syntax errors detected.")


def main() -> None:
    root = tk.Tk()
    SmartIDE(root)
    root.mainloop()


if __name__ == "__main__":
    main()
