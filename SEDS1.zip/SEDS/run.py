"""Smart Error Detection System (SEDS) - Launcher.

Usage:
    python run.py
"""

from __future__ import annotations

import os
import sys
import webbrowser
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from backend.app import app  # noqa: E402
from backend.database import Database  # noqa: E402


def main():
    print("=" * 60)
    print(" SMART ERROR DETECTION SYSTEM (SEDS)")
    print(" Tagline: Detect. Fix. Run. Automatically.")
    print("=" * 60)

    # Initialize Database
    Database.init_db()
    print("[*] SQLite Database initialized at seds.db")

    port = int(os.getenv("SEDS_PORT", "5000"))
    host = os.getenv("SEDS_HOST", "127.0.0.1")
    url = f"http://{host}:{port}"

    print(f"[*] SEDS Web IDE accessible at: {url}")
    print("[*] Press Ctrl+C to stop the server.\n")

    # Optionally open browser
    if "--no-browser" not in sys.argv:
        try:
            webbrowser.open(url)
        except Exception:
            pass

    app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    main()
