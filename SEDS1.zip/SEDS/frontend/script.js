/**
 * SEDS 2.0 - Smart Error Detection System Client Controller
 * Connects VS Code-inspired frontend to Python Flask Backend REST API.
 */

document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const codeEditor = document.getElementById("codeEditor");
  const lineNumbers = document.getElementById("lineNumbers");
  const cursorPos = document.getElementById("cursorPos");
  const footerLines = document.getElementById("footerLines");
  const currentFileName = document.getElementById("currentFileName");
  const statusBar = document.getElementById("statusBar");
  const statusText = document.getElementById("statusText");

  // AI Controls
  const aiConsentToggle = document.getElementById("aiConsentToggle");
  const aiProviderSelect = document.getElementById("aiProviderSelect");

  // Toolbar Buttons
  const btnRun = document.getElementById("btnRun");
  const btnOpenFile = document.getElementById("btnOpenFile");
  const fileInput = document.getElementById("fileInput");
  const btnSaveFile = document.getElementById("btnSaveFile");
  const btnClear = document.getElementById("btnClear");
  const btnScanProject = document.getElementById("btnScanProject");
  const btnUndoFix = document.getElementById("btnUndoFix");

  // Right Panel Elements
  const badgeErrorType = document.getElementById("badgeErrorType");
  const badgeLine = document.getElementById("badgeLine");
  const badgeCol = document.getElementById("badgeCol");
  const badgeProvider = document.getElementById("badgeProvider");
  const explWhat = document.getElementById("explWhat");
  const explWhere = document.getElementById("explWhere");
  const explWhy = document.getElementById("explWhy");
  const explCause = document.getElementById("explCause");
  const explAffected = document.getElementById("explAffected");
  const explHow = document.getElementById("explHow");

  const fixedCodeDisplay = document.getElementById("fixedCodeDisplay");
  const unifiedDiffDisplay = document.getElementById("unifiedDiffDisplay");
  const fixNotice = document.getElementById("fixNotice");
  const fixNoticeText = document.getElementById("fixNoticeText");
  const btnApplyFix = document.getElementById("btnApplyFix");
  const btnApplyAndRun = document.getElementById("btnApplyAndRun");

  // Bottom Panel Elements
  const terminalOutput = document.getElementById("terminalOutput");
  const bottomExecTime = document.getElementById("bottomExecTime");
  const bottomExitCode = document.getElementById("bottomExitCode");
  const diagMode = document.getElementById("diagMode");
  const diagExitCode = document.getElementById("diagExitCode");
  const diagDuration = document.getElementById("diagDuration");
  const diagStatus = document.getElementById("diagStatus");
  const diagNotice = document.getElementById("diagNotice");

  // Scanner Elements
  const scanFolderInput = document.getElementById("scanFolderInput");
  const btnStartScan = document.getElementById("btnStartScan");
  const scanSummaryBar = document.getElementById("scanSummaryBar");
  const scanTotalFiles = document.getElementById("scanTotalFiles");
  const scanPassedFiles = document.getElementById("scanPassedFiles");
  const scanFailedFiles = document.getElementById("scanFailedFiles");
  const scanDuration = document.getElementById("scanDuration");
  const scanResultsList = document.getElementById("scanResultsList");
  const scannerCountBadge = document.getElementById("scannerCountBadge");

  // History & Analytics Elements
  const btnHeaderHistory = document.getElementById("btnHeaderHistory");
  const sessionsList = document.getElementById("sessionsList");
  const statTotalSessions = document.getElementById("statTotalSessions");
  const statTotalErrors = document.getElementById("statTotalErrors");
  const statFixRate = document.getElementById("statFixRate");
  const statTopErrorsList = document.getElementById("statTopErrorsList");

  // Modal Elements
  const modalScan = document.getElementById("modalScan");
  const modalScanInput = document.getElementById("modalScanInput");
  const btnCloseModal = document.getElementById("btnCloseModal");
  const btnModalCancel = document.getElementById("btnModalCancel");
  const btnModalRunScan = document.getElementById("btnModalRunScan");
  const btnApiConfig = document.getElementById("btnApiConfig");

  // Dynamic API Base URL resolution (supports Vercel frontend calling Render backend)
  const getApiUrl = (endpoint) => {
    const base = (window.SEDS_API_BASE || localStorage.getItem("SEDS_API_BASE") || "").replace(/\/+$/, "");
    return `${base}${endpoint}`;
  };

  // Application State
  let undoStack = [];
  let currentSuggestedFix = null;
  let activeErrorLine = null;

  // 1. Line Numbers & Cursor Tracking
  function updateLineNumbers(highlightLine = null) {
    const lines = codeEditor.value.split("\n");
    const count = lines.length;
    let html = "";
    for (let i = 1; i <= count; i++) {
      if (highlightLine && i === highlightLine) {
        html += `<span class="error-marker">&gt; ${i}</span>\n`;
      } else {
        html += `${i}\n`;
      }
    }
    lineNumbers.innerHTML = html;
    footerLines.textContent = `${count} line${count > 1 ? "s" : ""}`;
  }

  function updateCursorPosition() {
    const text = codeEditor.value.substring(0, codeEditor.selectionStart);
    const lines = text.split("\n");
    const row = lines.length;
    const col = lines[lines.length - 1].length + 1;
    cursorPos.textContent = `Ln ${row}, Col ${col}`;
  }

  function highlightAndScrollToLine(lineNumber) {
    if (!lineNumber || lineNumber < 1) return;
    const lines = codeEditor.value.split("\n");
    let charOffset = 0;
    for (let i = 0; i < lineNumber - 1 && i < lines.length; i++) {
      charOffset += lines[i].length + 1;
    }
    const lineEnd = charOffset + (lines[lineNumber - 1] ? lines[lineNumber - 1].length : 0);
    codeEditor.focus();
    codeEditor.setSelectionRange(charOffset, lineEnd);
    const lineHeight = 20;
    codeEditor.scrollTop = Math.max(0, (lineNumber - 3) * lineHeight);
    lineNumbers.scrollTop = codeEditor.scrollTop;
  }

  codeEditor.addEventListener("input", () => {
    updateLineNumbers(activeErrorLine);
    updateCursorPosition();
  });

  codeEditor.addEventListener("keyup", updateCursorPosition);
  codeEditor.addEventListener("click", updateCursorPosition);

  // Sync scroll between editor and gutter
  codeEditor.addEventListener("scroll", () => {
    lineNumbers.scrollTop = codeEditor.scrollTop;
  });

  // Support Tab key indentation in editor
  codeEditor.addEventListener("keydown", (e) => {
    if (e.key === "Tab") {
      e.preventDefault();
      const start = codeEditor.selectionStart;
      const end = codeEditor.selectionEnd;
      codeEditor.value = codeEditor.value.substring(0, start) + "    " + codeEditor.value.substring(end);
      codeEditor.selectionStart = codeEditor.selectionEnd = start + 4;
      updateLineNumbers();
    } else if (e.ctrlKey && e.key === "Enter") {
      e.preventDefault();
      runCode();
    }
  });

  // 2. Status Updater
  function setStatus(text, type = "ready") {
    statusText.textContent = text;
    statusBar.className = `status-pill status-${type}`;
  }

  // 3. Terminal Logger
  function logTerminal(text, type = "normal") {
    const line = document.createElement("div");
    line.className = `terminal-line ${type === "error" ? "error-line" : type === "system" ? "system-line" : ""}`;
    line.textContent = text;
    terminalOutput.appendChild(line);
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
  }

  function clearTerminal() {
    terminalOutput.innerHTML = "";
  }

  // 4. Run Code Endpoint Handler
  async function runCode() {
    const code = codeEditor.value;
    if (!code.trim()) {
      setStatus("Editor is empty", "ready");
      return;
    }

    setStatus("Executing in Sandbox...", "running");
    clearTerminal();
    logTerminal(`[SEDS Runner] Executing code with ${aiConsentToggle.checked ? "AI Cloud Assist" : "Local Engine"}...`, "system");

    const payload = {
      code: code,
      user_consent: aiConsentToggle.checked,
      preferred_provider: aiProviderSelect.value,
    };

    try {
      const response = await fetch(getApiUrl("/api/run"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const data = await response.json();

      // Update Bottom Stats
      bottomExecTime.textContent = `Time: ${data.duration_ms} ms`;
      bottomExitCode.textContent = `Exit: ${data.exit_code}`;
      diagExitCode.textContent = data.exit_code;
      diagDuration.textContent = `${data.duration_ms} ms`;
      diagStatus.textContent = data.exit_code === 0 ? "Success" : "Error Occurred";
      if (data.security_notice) {
        diagNotice.textContent = data.security_notice;
      }

      // Display stdout / stderr
      if (data.stdout) {
        logTerminal(data.stdout);
      }
      if (data.stderr) {
        logTerminal(data.stderr, "error");
      }

      // Handle Errors vs Success
      if (data.exit_code === 0 && (!data.errors || data.errors.length === 0)) {
        setStatus("Success", "ready");
        activeErrorLine = null;
        updateLineNumbers();
        badgeErrorType.textContent = "No Errors";
        badgeErrorType.className = "badge badge-neutral";
        badgeLine.textContent = "Clean";
        badgeCol.textContent = "--";
        explWhat.textContent = "No runtime or static errors detected!";
        explWhere.textContent = "All statements executed successfully.";
        explWhy.textContent = "The code conforms to Python syntax and completed execution.";
        explCause.textContent = "None";
        explAffected.textContent = "None";
        explHow.textContent = "Your program is running smoothly.";
        currentSuggestedFix = null;
        btnApplyFix.disabled = true;
        btnApplyAndRun.disabled = true;
        fixedCodeDisplay.textContent = "No fix required - program executed with 0 errors.";
        unifiedDiffDisplay.textContent = "No diff available.";
      } else {
        const primary = data.primary_error || (data.errors && data.errors[0]);
        if (primary) {
          setStatus(`Error: ${primary.error_type}`, "error");
          activeErrorLine = primary.line;
          updateLineNumbers(activeErrorLine);
          highlightAndScrollToLine(primary.line);

          badgeErrorType.textContent = primary.error_type;
          badgeErrorType.className = "badge badge-error";
          badgeLine.textContent = `Line ${primary.line}`;
          badgeCol.textContent = `Col ${primary.column || 1}`;

          // Explanation
          if (data.explanation) {
            badgeProvider.textContent = data.explanation.provider === "ai" ? "Cloud AI" : "Local Engine";
            explWhat.textContent = data.explanation.what || primary.message;
            explWhere.textContent = data.explanation.where || `Line ${primary.line}`;
            explWhy.textContent = data.explanation.why || "Syntax or runtime exception encountered.";
            explCause.textContent = data.explanation.cause || primary.message;
            explAffected.textContent = data.explanation.affected || primary.source_snippet || `Line ${primary.line}`;
            explHow.textContent = data.explanation.how_to_fix || "Check line logic.";
          }

          // Suggested Fix
          if (data.fix && data.fix.fixed_code) {
            currentSuggestedFix = data.fix.fixed_code;
            fixedCodeDisplay.textContent = currentSuggestedFix;
            unifiedDiffDisplay.textContent = data.fix.diff || "No line diff available.";
            btnApplyFix.disabled = false;
            btnApplyAndRun.disabled = false;
            fixNotice.style.display = "flex";
            fixNoticeText.textContent = data.fix.validation_notes || "Suggested fix validated via AST.";
          } else {
            currentSuggestedFix = null;
            btnApplyFix.disabled = true;
            btnApplyAndRun.disabled = true;
            fixedCodeDisplay.textContent = "No automatic fix inferred. Follow the diagnostic instructions.";
            unifiedDiffDisplay.textContent = "No diff.";
            fixNotice.style.display = "none";
          }
        }
      }
    } catch (err) {
      setStatus("Network / Server Error", "error");
      logTerminal(`[SEDS Error] Failed to connect to server: ${err.message}`, "error");
    }
  }

  // 5. Apply Fix & Apply and Run
  function applyFix() {
    if (!currentSuggestedFix) return;
    undoStack.push(codeEditor.value);
    btnUndoFix.disabled = false;
    codeEditor.value = currentSuggestedFix;
    updateLineNumbers();
    setStatus("Fix applied", "ready");
    logTerminal("[SEDS] Candidate fix applied to editor.", "system");
  }

  btnApplyFix.addEventListener("click", applyFix);

  btnApplyAndRun.addEventListener("click", async () => {
    applyFix();
    await runCode();
  });

  btnUndoFix.addEventListener("click", () => {
    if (undoStack.length > 0) {
      codeEditor.value = undoStack.pop();
      updateLineNumbers();
      btnUndoFix.disabled = undoStack.length === 0;
      setStatus("Fix undone", "ready");
      logTerminal("[SEDS] Previous code state restored.", "system");
    }
  });

  // 6. File Operations (Open, Save, Clear)
  btnOpenFile.addEventListener("click", () => fileInput.click());

  fileInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        codeEditor.value = event.target.result;
        currentFileName.textContent = file.name;
        updateLineNumbers();
        setStatus(`Loaded ${file.name}`, "ready");
        logTerminal(`[SEDS] File opened: ${file.name}`, "system");
      };
      reader.readAsText(file);
    }
  });

  btnSaveFile.addEventListener("click", () => {
    const blob = new Blob([codeEditor.value], { type: "text/x-python;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = currentFileName.textContent || "script.py";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setStatus("File saved", "ready");
  });

  btnClear.addEventListener("click", () => {
    if (confirm("Clear code editor?")) {
      undoStack.push(codeEditor.value);
      btnUndoFix.disabled = false;
      codeEditor.value = "";
      updateLineNumbers();
      setStatus("Editor cleared", "ready");
    }
  });

  btnRun.addEventListener("click", runCode);

  // 7. Diff Tabs Switching
  document.querySelectorAll(".diff-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".diff-tab").forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".diff-tab-content").forEach((c) => c.classList.remove("active"));
      tab.classList.add("active");
      const target = tab.getAttribute("data-tab");
      if (target === "preview") {
        document.getElementById("fixPreviewTab").classList.add("active");
      } else {
        document.getElementById("fixDiffTab").classList.add("active");
      }
    });
  });

  // 8. Bottom Tabs Switching
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".bottom-tab-content").forEach((c) => c.classList.remove("active"));
      btn.classList.add("active");
      const tabName = btn.getAttribute("data-bottom-tab");
      const tabMap = {
        terminal: "tabTerminal",
        diagnostics: "tabDiagnostics",
        scanner: "tabScanner",
        history: "tabHistory",
      };
      const targetId = tabMap[tabName];
      if (targetId) {
        document.getElementById(targetId).classList.add("active");
      }
      if (tabName === "history") {
        fetchHistory();
      }
    });
  });

  // 9. Project Scanner Logic
  btnScanProject.addEventListener("click", () => {
    modalScan.style.display = "flex";
    modalScanInput.focus();
  });

  btnCloseModal.addEventListener("click", () => (modalScan.style.display = "none"));
  btnModalCancel.addEventListener("click", () => (modalScan.style.display = "none"));

  btnModalRunScan.addEventListener("click", () => {
    const path = modalScanInput.value.trim();
    if (!path) return;
    modalScan.style.display = "none";
    scanFolderInput.value = path;
    // Switch to scanner bottom tab
    document.querySelector('.tab-btn[data-bottom-tab="scanner"]').click();
    executeProjectScan(path);
  });

  btnStartScan.addEventListener("click", () => {
    const path = scanFolderInput.value.trim();
    if (path) {
      executeProjectScan(path);
    }
  });

  async function executeProjectScan(folderPath) {
    setStatus("Scanning Project...", "running");
    scanResultsList.innerHTML = `<div class="empty-state">Scanning Python files in ${folderPath}...</div>`;

    try {
      const resp = await fetch(getApiUrl("/api/scan"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder_path: folderPath }),
      });
      const data = await resp.json();

      if (!resp.ok) {
        throw new Error(data.error || "Failed to scan folder");
      }

      const report = data.report;
      scanSummaryBar.style.display = "flex";
      scanTotalFiles.textContent = report.total_files;
      scanPassedFiles.textContent = report.passed_files;
      scanFailedFiles.textContent = report.failed_files;
      scanDuration.textContent = `${report.duration_ms} ms`;

      scannerCountBadge.style.display = report.failed_files > 0 ? "inline-block" : "none";
      scannerCountBadge.textContent = report.failed_files;

      if (!report.files || report.files.length === 0) {
        scanResultsList.innerHTML = '<div class="empty-state">No Python files found in this directory.</div>';
        setStatus("Scan complete: 0 files", "ready");
        return;
      }

      let html = "";
      report.files.forEach((file) => {
        const isErr = file.status === "ERROR";
        html += `
          <div class="scan-file-card ${isErr ? "has-error" : "passed"}">
            <div style="display:flex; justify-content:space-between; font-weight:600; font-size:12px; margin-bottom:4px;">
              <span>${file.relative_path}</span>
              <span style="color: ${isErr ? "#f87171" : "#4ade80"}">${file.status}</span>
            </div>
            <div style="font-size:11px; color:#94a3b8;">${file.file_path}</div>
            ${
              file.errors && file.errors.length > 0
                ? file.errors
                    .map(
                      (err) => `
                <div style="margin-top:6px; padding:4px 8px; background:#141414; border-radius:4px; font-size:11px; color:#f87171;">
                  Line ${err.line}: [${err.error_type}] ${err.message}
                </div>
              `
                    )
                    .join("")
                : ""
            }
          </div>
        `;
      });
      scanResultsList.innerHTML = html;
      setStatus(`Scan complete: ${report.failed_files} error(s)`, report.failed_files > 0 ? "error" : "ready");
    } catch (err) {
      scanResultsList.innerHTML = `<div class="empty-state" style="color:#f87171;">Scan Error: ${err.message}</div>`;
      setStatus("Scan failed", "error");
    }
  }

  // 10. History & Analytics Fetcher
  async function fetchHistory() {
    try {
      const resp = await fetch(getApiUrl("/api/history"));
      const data = await resp.json();

      // Update Analytics
      statTotalSessions.textContent = data.analytics.total_sessions || 0;
      statTotalErrors.textContent = data.analytics.total_errors_detected || 0;
      const rate =
        data.analytics.total_errors_detected > 0
          ? Math.round((data.analytics.fixes_applied / data.analytics.total_errors_detected) * 100)
          : 0;
      statFixRate.textContent = `${rate}%`;

      // Top errors
      statTopErrorsList.innerHTML = "";
      if (data.analytics.top_errors && data.analytics.top_errors.length > 0) {
        data.analytics.top_errors.forEach((e) => {
          const li = document.createElement("li");
          li.textContent = `${e.error_type}: ${e.count} occurrence(s)`;
          statTopErrorsList.appendChild(li);
        });
      } else {
        statTopErrorsList.innerHTML = "<li>No error history recorded yet.</li>";
      }

      // Sessions list
      sessionsList.innerHTML = "";
      if (data.sessions && data.sessions.length > 0) {
        data.sessions.forEach((s) => {
          const item = document.createElement("div");
          item.className = "history-item";
          item.innerHTML = `
            <span><strong>${s.title}</strong> (${s.error_type || "Success"})</span>
            <span style="color:#858585;">${s.created_at}</span>
          `;
          item.addEventListener("click", () => {
            codeEditor.value = s.source_code;
            updateLineNumbers();
            setStatus(`Loaded past session #${s.id}`, "ready");
          });
          sessionsList.appendChild(item);
        });
      } else {
        sessionsList.innerHTML = '<div class="empty-state">No previous sessions found.</div>';
      }
    } catch (err) {
      console.error("Failed to load history:", err);
    }
  }

  btnHeaderHistory.addEventListener("click", () => {
    document.querySelector('.tab-btn[data-bottom-tab="history"]').click();
  });

  // Check initial system status
  async function initStatus() {
    try {
      const resp = await fetch(getApiUrl("/api/status"));
      const data = await resp.json();
      if (data.ai) {
        if (data.ai.openai_configured || data.ai.gemini_configured) {
          aiConsentToggle.checked = true;
          logTerminal("[SEDS] AI API key detected in environment. AI Cloud Assist active upon consent.", "system");
        } else {
          logTerminal("[SEDS] Running in offline heuristic mode (No external API keys required).", "system");
        }
      }
    } catch (e) {
      console.warn("Status check failed:", e);
    }
  }

  if (btnApiConfig) {
    btnApiConfig.addEventListener("click", () => {
      const current = localStorage.getItem("SEDS_API_BASE") || "";
      const input = prompt("Enter your Render Backend URL (or leave blank for default / Vercel proxy):", current);
      if (input !== null) {
        const clean = input.trim().replace(/\/+$/, "");
        if (clean) {
          localStorage.setItem("SEDS_API_BASE", clean);
          logTerminal(`[SEDS Config] Backend API URL set to: ${clean}`, "system");
        } else {
          localStorage.removeItem("SEDS_API_BASE");
          logTerminal("[SEDS Config] Backend API URL reset to default relative proxy.", "system");
        }
        initStatus();
      }
    });
  }

  // Initialize
  updateLineNumbers(1);
  updateCursorPosition();
  initStatus();
});
