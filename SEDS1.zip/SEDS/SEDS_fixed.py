#!/usr/bin/env python3
"""Smart Error Detection System (SEDS) - safer starter desktop IDE.

Note: this is a local development tool, NOT a secure public code-execution
sandbox. Do not run untrusted code on a machine containing sensitive data.
"""

import ast
import os
import re
import subprocess
import sys
import tempfile
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext


TITLE = "Smart Error Detection System (SEDS)"
BG = "#1e1e1e"
FG = "#d4d4d4"
ACCENT = "#2563eb"
SUCCESS = "#16a34a"
WARNING = "#f59e0b"
FONT = ("Consolas", 11)


def explain_error(error_type, error_msg):
    """Explain common Python exceptions in beginner-friendly language."""
    explanations = {
        "SyntaxError": "Python cannot parse the code. Check quotes, brackets, commas, and colons.",
        "IndentationError": "A line has unexpected indentation or is not indented where Python requires it.",
        "TabError": "The code mixes tabs and spaces. Use four spaces consistently.",
        "NameError": "A variable or function is being used before it has been defined, or its name is misspelled.",
        "TypeError": "An operation or function received a value of an incompatible type.",
        "ValueError": "The value has the right general type, but it is not valid for this operation.",
        "IndexError": "The requested list or sequence position does not exist.",
        "KeyError": "The requested dictionary key does not exist.",
        "ZeroDivisionError": "The program tried to divide by zero.",
        "AttributeError": "The object does not have the attribute or method being accessed.",
        "FileNotFoundError": "The program tried to open a file that could not be found.",
        "ImportError": "Python could not import the requested module or name.",
        "ModuleNotFoundError": "A required Python module is not installed or cannot be found.",
        "Timeout": "The program ran longer than the allowed time limit.",
    }
    return explanations.get(error_type, "The program stopped because of an error. Read the traceback for details.")


def parse_traceback(stderr):
    """Return exception type, message and best matching user-code line."""
    lines = [line.rstrip() for line in stderr.splitlines() if line.strip()]
    error_line = None
    for line in lines:
        match = re.search(r'File ".*", line (\d+)', line)
        if match:
            error_line = int(match.group(1))

    last = lines[-1] if lines else "Unknown error"
    match = re.match(r"([A-Za-z_][A-Za-z0-9_.]*):\s*(.*)", last)
    if match:
        return match.group(1), match.group(2), error_line
    if "SyntaxError" in last:
        return "SyntaxError", last, error_line
    return "Error", last, error_line


def make_safe_suggestion(source, error_type, error_msg, line_number):
    """Offer conservative suggestions; never invent values for the user."""
    lines = source.splitlines()
    if error_type in ("IndentationError", "TabError"):
        candidate = source.expandtabs(4)
        try:
            compile(candidate, "<seds-check>", "exec")
            return candidate, "Converted tab characters to four spaces. Review indentation before applying."
        except SyntaxError:
            return None, "Use consistent four-space indentation. The correct block structure needs review."

    if error_type == "SyntaxError" and line_number and 1 <= line_number <= len(lines):
        target = lines[line_number - 1]
        if "expected ':'" in error_msg:
            stripped = target.rstrip()
            if re.match(r"^\s*(if|elif|else|for|while|def|class|try|except|finally|with)\b", stripped) and not stripped.endswith(":"):
                candidate_lines = lines[:]
                candidate_lines[line_number - 1] = stripped + ":"
                candidate = "\n".join(candidate_lines) + ("\n" if source.endswith("\n") else "")
                try:
                    compile(candidate, "<seds-check>", "exec")
                    return candidate, f"Added a colon to line {line_number}. The candidate passed a syntax check."
                except SyntaxError:
                    return None, "A colon may be missing, but other syntax issues remain. Review the highlighted line."

    guidance = {
        "ZeroDivisionError": "Check the denominator before dividing. For example: if denominator != 0: result = numerator / denominator. SEDS will not guess a replacement value.",
        "NameError": "Check the spelling and scope of the variable/function. Define it with the intended value before use.",
        "IndexError": "Check the sequence length before indexing, for example: if items: value = items[index]. Confirm the intended index.",
        "TypeError": "Check the types of the values passed to the operation or function. Convert only when that matches your intended behavior.",
        "KeyError": "Check whether the key exists, or use dictionary.get(key) if a default value is appropriate.",
        "ValueError": "Check the input value and validate it before conversion or processing.",
        "AttributeError": "Check the object's type and whether the attribute or method name is correct.",
    }
    return None, guidance.get(error_type, "No safe automatic change could be generated. Use the traceback and explanation to edit the code.")


class SEDSApp:
    def __init__(self, root):
        self.root = root
        self.root.title(TITLE)
        self.root.geometry("1250x780")
        self.root.configure(bg=BG)
        self.current_file = None
        self.last_candidate = None
        self._build_ui()
        self.editor.insert("1.0", 'print("Hello from SEDS!")\n')

    def _build_ui(self):
        top = tk.Frame(self.root, bg=BG)
        top.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(top, text=TITLE, bg=BG, fg="white", font=("Arial", 15, "bold")).pack(side=tk.LEFT)
        self.status = tk.Label(top, text="Ready", bg=BG, fg=FG)
        self.status.pack(side=tk.RIGHT)

        panes = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, bg=BG, sashwidth=6)
        panes.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)

        left = tk.Frame(panes, bg=BG)
        right = tk.Frame(panes, bg=BG)
        panes.add(left, width=650)
        panes.add(right, width=570)

        tk.Label(left, text="Python Code Editor", bg=BG, fg="white",
                 font=("Arial", 12, "bold")).pack(anchor="w")
        self.editor = scrolledtext.ScrolledText(
            left, wrap=tk.NONE, bg="#101010", fg=FG, insertbackground="white",
            font=FONT, undo=True
        )
        self.editor.pack(fill=tk.BOTH, expand=True, pady=6)
        self.editor.tag_configure("error_line", background="#5b2020")
        self.editor.bind("<KeyRelease>", lambda _event: self.clear_highlight())

        buttons = tk.Frame(left, bg=BG)
        buttons.pack(fill=tk.X, pady=4)
        self._button(buttons, "Run", self.run_code, ACCENT)
        self._button(buttons, "Open", self.open_file)
        self._button(buttons, "Save", self.save_file)
        self._button(buttons, "Clear", self.clear_editor)
        self._button(buttons, "Scan Project", self.scan_project, "#6d28d9")

        tk.Label(right, text="Error Explanation", bg=BG, fg="white",
                 font=("Arial", 12, "bold")).pack(anchor="w")
        self.explanation = scrolledtext.ScrolledText(
            right, height=8, wrap=tk.WORD, bg="#252526", fg="#9cdcfe", font=FONT
        )
        self.explanation.pack(fill=tk.X, pady=5)

        tk.Label(right, text="Suggested Fix / Guidance", bg=BG, fg="white",
                 font=("Arial", 12, "bold")).pack(anchor="w")
        self.fix_box = scrolledtext.ScrolledText(
            right, height=9, wrap=tk.NONE, bg="#252526", fg="#ce9178", font=FONT
        )
        self.fix_box.pack(fill=tk.X, pady=5)

        fix_buttons = tk.Frame(right, bg=BG)
        fix_buttons.pack(fill=tk.X)
        self._button(fix_buttons, "Apply Fix", self.apply_fix, SUCCESS)
        self._button(fix_buttons, "Run Again", self.run_code, ACCENT)

        tk.Label(right, text="Terminal Output", bg=BG, fg="white",
                 font=("Arial", 12, "bold")).pack(anchor="w", pady=(8, 0))
        self.terminal = scrolledtext.ScrolledText(
            right, wrap=tk.WORD, bg="black", fg="#00ff66", font=FONT
        )
        self.terminal.pack(fill=tk.BOTH, expand=True, pady=5)

        tk.Label(
            self.root,
            text="Security: runs code locally with your Windows permissions. Only run code you trust.",
            bg=BG, fg="#fbbf24", anchor="w"
        ).pack(fill=tk.X, padx=10, pady=(0, 6))

    @staticmethod
    def _button(parent, label, command, color="#333333"):
        tk.Button(parent, text=label, command=command, bg=color, fg="white",
                  activebackground=color, activeforeground="white",
                  relief=tk.FLAT, padx=10, pady=5).pack(side=tk.LEFT, padx=3)

    def clear_highlight(self):
        self.editor.tag_remove("error_line", "1.0", tk.END)

    def highlight_line(self, line):
        self.clear_highlight()
        if line and line > 0:
            start = f"{line}.0"
            end = f"{line}.end"
            self.editor.tag_add("error_line", start, end)
            self.editor.see(start)

    def _show_error(self, error_type, error_msg, line, stderr):
        self.highlight_line(line)
        self.explanation.delete("1.0", tk.END)
        location = f"Line {line}" if line else "Line not identified"
        self.explanation.insert(
            tk.END,
            f"Error Type: {error_type}\n{location}\n\n"
            f"Explanation:\n{explain_error(error_type, error_msg)}\n\n"
            f"Python message:\n{error_msg}\n"
        )
        candidate, guidance = make_safe_suggestion(
            self.editor.get("1.0", "end-1c"), error_type, error_msg, line
        )
        self.last_candidate = candidate
        self.fix_box.delete("1.0", tk.END)
        if candidate is not None:
            self.fix_box.insert(tk.END, candidate)
            self.explanation.insert(tk.END, "\nA candidate fix was generated and syntax-checked. Review it before applying.")
        else:
            self.fix_box.insert(tk.END, "No safe automatic code change generated.\n\n" + guidance)
        self.terminal.insert(tk.END, "\n" + stderr)

    def run_code(self):
        source = self.editor.get("1.0", "end-1c")
        self.terminal.delete("1.0", tk.END)
        self.explanation.delete("1.0", tk.END)
        self.fix_box.delete("1.0", tk.END)
        self.last_candidate = None
        self.clear_highlight()
        self.status.config(text="Running...")
        self.root.update_idletasks()

        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".py", delete=False, encoding="utf-8", newline="\n"
            ) as temp:
                temp.write(source)
                temp_path = temp.name

            working_dir = str(Path(self.current_file).parent) if self.current_file else os.getcwd()
            result = subprocess.run(
                [sys.executable, "-I", temp_path],
                capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=5, cwd=working_dir
            )
            output = result.stdout
            if result.stderr:
                output += ("\n" if output else "") + result.stderr
            self.terminal.insert(tk.END, output.rstrip() or "Program executed successfully (no output).")

            if result.returncode != 0:
                error_type, error_msg, line = parse_traceback(result.stderr)
                self._show_error(error_type, error_msg, line, "")
                self.status.config(text=f"Error: {error_type}")
            else:
                self.status.config(text="Success")
                self.explanation.insert(tk.END, "No runtime error detected.")
        except subprocess.TimeoutExpired:
            self.status.config(text="Timed out")
            self.explanation.insert(tk.END, explain_error("Timeout", "Time limit exceeded"))
            self.terminal.insert(tk.END, "\nStopped: execution exceeded 5 seconds.")
        except Exception as exc:
            self.status.config(text="Runner error")
            self.terminal.insert(tk.END, f"SEDS runner error: {exc}")
        finally:
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

    def apply_fix(self):
        if not self.last_candidate:
            messagebox.showinfo("SEDS", "There is no validated automatic fix to apply. Follow the guidance instead.")
            return
        if not messagebox.askyesno("Apply Fix", "Replace the editor contents with the suggested candidate fix?"):
            return
        self.editor.delete("1.0", tk.END)
        self.editor.insert("1.0", self.last_candidate)
        self.last_candidate = None
        self.clear_highlight()
        self.status.config(text="Candidate fix applied - run again to test")
        self.fix_box.delete("1.0", tk.END)
        self.explanation.delete("1.0", tk.END)

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("Python files", "*.py"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as file:
                content = file.read()
            self.editor.delete("1.0", tk.END)
            self.editor.insert("1.0", content)
            self.current_file = path
            self.root.title(f"{TITLE} - {Path(path).name}")
            self.status.config(text="File opened")
        except (OSError, UnicodeError) as exc:
            messagebox.showerror("Open Error", str(exc))

    def save_file(self):
        path = self.current_file or filedialog.asksaveasfilename(
            defaultextension=".py", filetypes=[("Python files", "*.py")]
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8", newline="\n") as file:
                file.write(self.editor.get("1.0", "end-1c"))
            self.current_file = path
            self.root.title(f"{TITLE} - {Path(path).name}")
            self.status.config(text="File saved")
        except OSError as exc:
            messagebox.showerror("Save Error", str(exc))

    def clear_editor(self):
        self.editor.delete("1.0", tk.END)
        self.current_file = None
        self.root.title(TITLE)
        self.clear_highlight()
        self.status.config(text="Editor cleared")

    def scan_project(self):
        folder = filedialog.askdirectory(title="Select Python project folder")
        if not folder:
            return
        excluded = {".git", ".venv", "venv", "__pycache__", "node_modules"}
        report = []
        self.status.config(text="Scanning project...")
        self.terminal.delete("1.0", tk.END)
        self.root.update_idletasks()

        for current_root, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if d not in excluded]
            for filename in files:
                if not filename.endswith(".py"):
                    continue
                path = os.path.join(current_root, filename)
                try:
                    with open(path, "r", encoding="utf-8") as file:
                        source = file.read()
                    ast.parse(source, filename=path)
                    report.append((path, "PASS", "Syntax is valid"))
                except SyntaxError as exc:
                    report.append((path, "SYNTAX ERROR", f"Line {exc.lineno}: {exc.msg}"))
                except (OSError, UnicodeError) as exc:
                    report.append((path, "READ ERROR", str(exc)))

        if not report:
            self.terminal.insert(tk.END, "No Python files found.")
            self.status.config(text="Scan complete: 0 files")
            return

        for path, state, detail in report:
            self.terminal.insert(tk.END, f"[{state}] {path}\n    {detail}\n\n")
        total = len(report)
        errors = sum(state == "SYNTAX ERROR" for _, state, _ in report)
        read_errors = sum(state == "READ ERROR" for _, state, _ in report)
        self.terminal.insert(
            tk.END,
            f"===== SEDS PROJECT SCAN REPORT =====\n"
            f"Python files checked: {total}\n"
            f"Syntax errors: {errors}\n"
            f"Read errors: {read_errors}\n"
            f"Syntax passes: {total - errors - read_errors}\n"
            f"Note: this scan checks syntax only, not runtime behavior.\n"
        )
        self.status.config(text=f"Scan complete: {errors} syntax errors")


def main():
    root = tk.Tk()
    SEDSApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
